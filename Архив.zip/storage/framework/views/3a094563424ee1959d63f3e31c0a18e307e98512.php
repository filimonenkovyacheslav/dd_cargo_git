<?php $__env->startSection('content'); ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>

					<div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th>Роль</th>
									<th>Имя</th>									
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
									<th>Изменить</th>
									<?php endif; ?> 
								</tr>
							</thead>
							<tbody>

								<?php for($i=0; $i < count($viewer_arr); $i++): ?>

								<tr>
									<?php
									$td = false;
									?>
								<td><?php echo e($viewer_arr[$i]); ?></td>
								
								<?php if(count($partners)): ?>
									
									<?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<?php if($partner->role === $viewer_arr[$i]): ?>
										
										<td><?php echo e($partner->name); ?></td>
										<?php
										$td = true;
										?>
										<?php break; ?>
							
										<?php endif; ?>
                                
	                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                <?php if(!$td): ?>
	                                <td></td>
	                                <?php endif; ?>
                                
                                <?php else: ?>
									<td></td>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
                                    <td>
                                    	<a class="btn btn-primary" href="<?php echo e(url('/admin/partners-up/'.$viewer_arr[$i])); ?>">Изменить</a>
                                    </td>
                                <?php endif; ?> 

                                </tr>
                                
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>