<style type="text/css">
	td,th {
		min-width: 100px;
		border: 1px solid black;
		padding: 10px;
	}
	table{
		border-collapse: collapse;
		border: 2px solid black;
		text-align: center;
		vertical-align: middle;
	}
</style>
<center>	
	<?php if($cancel): ?>
	<h1 style="color:red">CANCELED</h1>
	<?php endif; ?>
	
	<table>
		<tr>
			<th colspan="4" style="font-size:24px">
				<p style="font-size:30px">ORIENTAL EXPRESS</p>
				<span style="font-style: italic">PACKING LIST <?php echo e($document->uniq_id); ?></span>
			</th>
		</tr>
		<tr style="font-style: italic">
			<th>Date <?php echo e($_SERVER['SERVER_NAME']); ?></th>
			<td><?php echo e($document->date); ?></td>
			<th>Dimensions</th>	
			<td><?php echo e($worksheet->width); ?>x<?php echo e($worksheet->height); ?>x<?php echo e($worksheet->length); ?></td>
					
		</tr>
		<tr style="font-style: italic">
			<th>TRACKING NO</th>	
			<td><?php echo e($tracking); ?></td>
			<th>Freight Cost</th>
			<td><?php echo e($worksheet->shipment_val); ?></td>					
		</tr>			
		<tr>
			<th colspan="2">SENDER</th>
			<th colspan="2">RECIPIENT</th>
		</tr>	
		<tr>
			<th>FULL NAME</th>
			<td><?php echo e($worksheet->shipper_name); ?></td>
			<th>FULL NAME</th>	
			<td><?php echo e($worksheet->consignee_name); ?></td>		
		</tr>	
		<tr>
			<th rowspan="5">ADDRESS</th>
			<td rowspan="5"><?php echo e($worksheet->shipper_address); ?></td>
			<th>HOUSE NAME / ADDRESS</th>	
			<td><?php echo e(($worksheet->house_name)?$worksheet->house_name.' / ':''); ?><?php echo e($worksheet->consignee_address); ?></td>		
		</tr>
		<tr>
			<th>LOCAL POST OFFICE</th>	
			<td><?php echo e($worksheet->post_office); ?></td>		
		</tr>
		<tr>
			<th>DISTRICT / CITY</th>	
			<td><?php echo e($worksheet->district); ?></td>		
		</tr>
		<tr>
			<th>STATE PINCODE</th>	
			<td><?php echo e($worksheet->state_pincode); ?></td>		
		</tr>
		<tr>
			<th>COUNTRY</th>	
			<td><?php echo e($worksheet->consignee_country); ?></td>		
		</tr>
		<tr>
			<th>PHONE</th>
			<td><?php echo e($worksheet->standard_phone); ?></td>
			<th>PHONE</th>	
			<td><?php echo e($worksheet->consignee_phone); ?></td>		
		</tr>
		<tr>
			<th colspan="4">DESCRIPTION OF THE ITEMS SHIPPED</th>
		</tr>
		<tr>
			<th>No.</th>
			<th>Description</th>
			<th>Quantity</th>	
			<th>Value of Goods</th>		
		</tr>
		<?php
		$number = 1;
		$items = explode(";", $worksheet->shipped_items);            
		?>

		<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<?php if(strripos($item, ':') !== false): ?>
			<tr>
				<td><?php echo e($number); ?></td>
				<td><?php echo e(explode(":", $item)[0]); ?></td>
				<td><?php echo e(explode(":", $item)[1]); ?></td>
				<td><?php echo e($worksheet->shipment_val); ?></td>
			</tr>
			<?php elseif(strripos($item, '-') !== false): ?>
			<tr>
				<td><?php echo e($number); ?></td>
				<td><?php echo e(explode("-", $item)[0]); ?></td>
				<td><?php echo e(explode("-", $item)[1]); ?></td>
				<td><?php echo e($worksheet->shipment_val); ?></td>
			</tr>
			<?php
			$number++;
			?>
			<?php endif; ?>			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th colspan="3">Declared value :</th>	
			<td><?php echo e($worksheet->shipment_val); ?></td>		
		</tr>
		<tr>
			<td colspan="4" style="text-align: left;">
				Hereby by signing this packing list I declare:
				<br>
				1) The goods in this parcel are handed over by me to the transporters and are my personal goods. Courier / Logistics Companies are just facilitators for shipping my cargo / goods - and hold no responsibility for breakage / shortage / damage or content of cargo is my responsibility - and we abide my all laws of local country as there , and well versed for same. 
				<br>
				2) Further these used/old if household goods then bear no commercial value and are not for sale. 
				<br>
				3) I guarantee that I provided true and complete information about the items shipped in this parcel. In case of any false or incomplete data I recognize my obligation to cover all legal penalties in origin, destination, and transit countries as well as to pay the costs incurred through my fault caused with delays in customs clearance and/or return of the parcel from a warehouse in Israel or from the destination country to me.				
			</td>
		</tr>
		<tr>
			<th>CUSTOMER NAME</th>	
			<td colspan="3"><?php echo e($worksheet->shipper_name); ?></td>		
		</tr>
		<tr>
			<th>CUSTOMER SIGNATURE</th>	
			<td colspan="3"><img src="<?php echo e(asset('/upload/signatures/'.$document->signature)); ?>" style="width:120px;height:100px"></td>		
		</tr>
	</table>
</center>






