<?php $__env->startSection('content'); ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Control Panel</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminPhilIndIndex')); ?>">Control Panel</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
					<a class="btn btn-primary btn-move" href="<?php echo e(route('showPhilIndUser')); ?>">Add</a>
					<?php endif; ?> 
					<div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th>Name</th>
									<th>E-mail</th>
									<th>Role</th>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
									<th>Change</th>
									<?php endif; ?> 
								</tr>
							</thead>
							<tbody>
								
								<?php if(isset($users)): ?>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
								<tr>
									<td><?php echo e($user->name); ?></td>
									<td><?php echo e($user->email); ?></td>
									<td><?php echo e($user->role); ?></td>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
                                    <td>
                                    	<a class="btn btn-primary" href="<?php echo e(url('/admin/phil-ind-users/'.$user->id)); ?>">Change</a>
                                    	<?php echo Form::open(['url'=>route('deletePhilIndUser'),'onsubmit' => 'return ConfirmDelete()', 'class'=>'form-horizontal','method' => 'POST']); ?>

                                    	<?php echo Form::hidden('email',$user->email); ?>

                                    	<?php echo Form::hidden('action',$user->id); ?>

                                    	<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

                                    	<?php echo Form::close(); ?>

                                    </td>
                                    <?php endif; ?> 
                                
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<script>

	function ConfirmDelete()
	{
		var x = confirm("Are you sure you want to delete?");
		if (x)
			return true;
		else
			return false;
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.phil_ind_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>