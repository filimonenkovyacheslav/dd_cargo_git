<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Control Panel</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminPhilIndIndex')); ?>">Control Panel</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->

<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>

					<?php if(session('status-error')): ?>
					<div class="alert alert-danger">
						<?php echo e(session('status-error')); ?>

					</div>
					<?php elseif(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<?php
						session(['this_previous_url' => url()->full()]);
					?>

					<div class="btn-move-wrapper" style="display:flex">
						<form action="<?php echo e(route('updatesArchiveFilter')); ?>" method="GET" id="form-worksheet-table-filter" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<label class="table_columns" style="margin: 0 15px">Choose column:
								<select class="form-control" id="table_columns" name="table_columns">
									<option value="" selected="selected"></option>
									<option value="worksheet_id">Worksheet Id</option>
									<option value="eng_worksheet_id">Eng Worksheet Id</option>
									<option value="draft_id">Draft Id</option>
									<option value="eng_draft_id">Eng Draft Id</option>
									<option value="updates_date">Updates Date</option>
									<option value="user_name">User Name</option>
									<option value="column_name">Column Name</option>
									<option value="old_data">Old Data</option>
                					<option value="new_data">New Data</option>
								</select>
							</label>
							<label>Filter:
								<input type="search" name="table_filter_value" class="form-control form-control-sm">
							</label>

							<input type="hidden" name="for_active">
							
							<button type="button" id="table_filter_button" style="margin-left:30px" class="btn btn-default">Search</button>
						</form>
					
					</div>
					
					<div class="card-body new-worksheet">
						<div class="table-container">
							<!-- <table id="bootstrap-data-table" class="table table-striped table-bordered"> -->
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>V</th>
										<th>Delete</th>
										<th>Worksheet Id</th>
										<th>Eng Worksheet Id</th>
										<th>Draft Id</th>
										<th>Eng Draft Id</th>
										<th>Updates Date</th>
										<th>User Name</th>
										<th>Column Name</th>
										<th>Old Data</th>
										<th>New Data</th>			
									</tr>

								</thead>
								<tbody>

									<?php if(isset($updates_archive_obj)): ?>
									<?php $__currentLoopData = $updates_archive_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
									<tr>
										<td class="td-checkbox">
											<input type="checkbox" name="row_id[]" value="<?php echo e($row->id); ?>">
										</td>
										<td class="td-button">

											<?php echo Form::open(['url'=>route('deleteUpdatesArchive'),'onsubmit' => 'return ConfirmDelete()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('action',$row->id); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>

											
										</td>
										<td title="<?php echo e($row->worksheet_id); ?>">
											<div class="div-number"><?php echo e($row->worksheet_id); ?></div>
										</td>
										<td title="<?php echo e($row->eng_worksheet_id); ?>">
											<div class="div-number"><?php echo e($row->eng_worksheet_id); ?></div>
										</td>
										<td title="<?php echo e($row->draft_id); ?>">
											<div class="div-number"><?php echo e($row->draft_id); ?></div>
										</td>
										<td title="<?php echo e($row->eng_draft_id); ?>">
											<div class="div-number"><?php echo e($row->eng_draft_id); ?></div>
										</td>
										<td title="<?php echo e($row->updates_date); ?>">
											<div class="div-3"><?php echo e($row->updates_date); ?></div>
										</td>
										<td title="<?php echo e($row->user_name); ?>">
											<div class="div-3"><?php echo e($row->user_name); ?></div>
										</td>
										<td title="<?php echo e($row->column_name); ?>">
											<div class="div-3"><?php echo e($row->column_name); ?></div>
										</td>
										<td title="<?php echo e($row->old_data); ?>">
											<div class="div-3"><?php echo e($row->old_data); ?></div>
										</td>
										<td title="<?php echo e($row->new_data); ?>">
											<div class="div-3"><?php echo e($row->new_data); ?></div>
										</td>
                                                           
									</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>

							<?php if(isset($data)): ?>
							<?php echo e($updates_archive_obj->appends($data)->links()); ?>

							<?php else: ?>
							<?php echo e($updates_archive_obj->links()); ?>

							<?php endif; ?>	

							<div class="checkbox-operations">

								<label>Select action with selected rows:
									<select class="form-control" name="checkbox_operations_select">
										<option value=""></option>
										<option value="delete">Delete</option>
									</select>
								</label>	

								<label class="value-by-tracking checkbox-operations-change">
								</label>

								<?php echo Form::open(['url'=>route('destroyArchiveById'),'onsubmit' => 'return ConfirmDelete()','method' => 'POST']); ?>

								<?php echo Form::button('Delete',['class'=>'btn btn-danger  checkbox-operations-delete','type'=>'submit']); ?>

								<?php echo Form::close(); ?>


							</div>						
						
						</div>
					</div>
				</div>
			</div><!-- .col-md-12 -->
		</div><!-- .row -->		
		
	</div><!-- .animated -->
</div><!-- .content -->

<script>

	function ConfirmDelete()
	{
		var x = confirm("Are you sure you want to delete?");
		if (x)
			return true;
		else
			return false;
	}

</script>

<?php else: ?>
<h1>Вы не можете просматривать эту страницу (You cannot view this page)!</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.phil_ind_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>