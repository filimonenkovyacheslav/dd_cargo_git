<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Control Panel</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminPhilIndIndex')); ?>">Control Panel</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->

<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>		

					<?php if(session('status-error')): ?>
					<div class="alert alert-danger">
						<?php echo e(session('status-error')); ?>

					</div>
					<?php elseif(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<?php
						session(['this_previous_url' => url()->full()]);
					?>	

					<div class="btn-move-wrapper" style="display:flex">
						<form action="<?php echo e(route('receiptsArchiveFilter')); ?>" method="GET" id="form-worksheet-table-filter" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<label class="table_columns" style="margin: 0 15px">Выберите колонку (Choose column):
								<select class="form-control" id="table_columns" name="table_columns">
									<option value="" selected="selected"></option>
									<option value="receipt_number">№ квитанции (Receipt number)</option>
									<option value="tracking_main">Номер посылки (Tracking number)</option>			
									<option value="description">Описание (Description)</option> 
									<option value="comment">Комментарий (Comment)</option>              
								</select>
							</label>
							<label>Фильтр (Filter):
								<input type="search" name="table_filter_value" class="form-control form-control-sm">
							</label>
							<button type="button" id="table_filter_button" style="margin-left:30px" class="btn btn-default">Поиск (Search)</button>
						</form>
					</div>
					
					<div class="card-body new-worksheet">
						<div class="table-container">
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>№ квитанции (Receipt number)</th>
										<th>Номер посылки (Tracking number)</th>
										<th>Описание (Description)</th>
										<th>Комментарий (Comment)</th>
										<th>Изменить (Change)</th>
									</tr>

								</thead>
								<tbody>

									<?php if(isset($archive_obj)): ?>
									<?php $__currentLoopData = $archive_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td title="<?php echo e($row->receipt_number); ?>">
											<div class="div-3"><?php echo e($row->receipt_number); ?></div>
										</td>
										<td title="<?php echo e($row->tracking_main); ?>">
											<div style="width: 120px"><?php echo e($row->tracking_main); ?></div>
										</td>										
										<td title="<?php echo e($row->description); ?>">
											<div style="width: 600px"><?php echo e($row->description); ?></div>
										</td>
										<td title="<?php echo e($row->comment); ?>">
											<div style="width: 200px"><?php echo e($row->comment); ?></div>
										</td>
										<td class="td-button"> 

											<a class="btn btn-primary" href="<?php echo e(url('/admin/receipts-archive-update/'.$row->id)); ?>">Редактировать</a>
										
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
										
										<?php echo Form::open(['url'=>route('deleteReceiptArchive'),'onsubmit' => 'return ConfirmDelete()', 'class'=>'form-horizontal','method' => 'POST']); ?>

										<?php echo Form::hidden('action',$row->id); ?>

										<?php echo Form::button('Удалить',['class'=>'btn btn-danger','type'=>'submit']); ?>

										<?php echo Form::close(); ?>

										
										<?php endif; ?>   

										</td>           
									
									</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>

							<?php if(isset($data)): ?>
							<?php echo e($archive_obj->appends($data)->links()); ?>

							<?php else: ?>
							<?php echo e($archive_obj->links()); ?>

							<?php endif; ?>
						
						</div>
					</div>
				</div>
			</div><!-- .col-md-12 -->
		</div><!-- .row -->		
		
	</div><!-- .animated -->
</div><!-- .content -->

<script type="text/javascript">
	function ConfirmDelete()
	{
		var x = confirm("Вы уверены, что хотите удалить?");
		if (x)
			return true;
		else
			return false;
	}
</script>

<?php else: ?>
<h1>Вы не можете просматривать эту страницу (You cannot view this page)!</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>