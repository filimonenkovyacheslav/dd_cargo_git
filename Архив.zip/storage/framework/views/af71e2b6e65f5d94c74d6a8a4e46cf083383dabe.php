<?php $__env->startSection('content'); ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
					<a class="btn btn-primary btn-move" href="<?php echo e(route('showUser')); ?>">Добавить</a>
					<?php endif; ?> 
					<div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th>Имя</th>
									<th>E-mail</th>
									<th>Роль</th>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
									<th>Изменить</th>
									<?php endif; ?> 
								</tr>
							</thead>
							<tbody>
								
								<?php if(isset($users)): ?>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
								<tr>
									<td><?php echo e($user->name); ?></td>
									<td><?php echo e($user->email); ?></td>
									<td><?php echo e($user->role); ?></td>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
                                    <td>
                                    	<a class="btn btn-primary" href="<?php echo e(url('/admin/users/'.$user->id)); ?>">Изменить</a>
                                    	<?php echo Form::open(['url'=>route('deleteUser'),'onsubmit' => 'return ConfirmDelete()', 'class'=>'form-horizontal','method' => 'POST']); ?>

                                    	<?php echo Form::hidden('email',$user->email); ?>

                                    	<?php echo Form::hidden('action',$user->id); ?>

                                    	<?php echo Form::button('Удалить',['class'=>'btn btn-danger','type'=>'submit']); ?>

                                    	<?php echo Form::close(); ?>

                                    </td>
                                    <?php endif; ?> 
                                
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<script>

	function ConfirmDelete()
	{
		var x = confirm("Вы уверены, что хотите удалить?");
		if (x)
			return true;
		else
			return false;
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>