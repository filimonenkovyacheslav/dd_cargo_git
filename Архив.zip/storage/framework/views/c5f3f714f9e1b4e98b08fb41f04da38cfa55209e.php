<style type="text/css">
	td {
		min-width: 100px;
	}
</style>
<center>
	<a href="<?php echo e(url('/download-pdf/'.$document->id)); ?>">Download PDF</a>
	<h1>Order No. <?php echo e($document->uniq_id); ?></h1>
	<h1>Tracking No. <?php echo e($tracking); ?></h1>
	<table>
		<tr>
			<td><h3>sender_name</h3></td>
			<td></td>
			<td colspan="3"><?php echo e($worksheet->sender_name); ?></td>			
		</tr>
		<tr>			
			<td><h3>sender_city</h3></td>
			<td></td>
			<td colspan="3"><?php echo e($worksheet->sender_city); ?></td>
		</tr>			
		<tr>			
			<td><h3>Date</h3></td>
			<td><?php echo e($document->date); ?></td>
			<td></td>
			<td><h3>Signature</h3></td>
			<td><img src="<?php echo e(asset('/upload/signatures/'.$document->signature)); ?>" style="width:120px;height:100px"></td>
		</tr>
	</table>
</center>






