<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<div class="card-body">					

						<?php echo Form::open(['url'=>route('addPhilIndData'), 'class'=>'form-horizontal worksheet-add-form','method' => 'POST']); ?>


						<?php echo Form::button('Save',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::button('Cancel selection',['class'=>'btn btn-danger', 'onclick' => 'handleCencel()']); ?>						

						<div id="checkbox-group">

						<?php $__currentLoopData = $date_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
							<div class="form-group">
							<?php echo Form::label('tracking[]', $number,['class' => 'col-md-2 control-label']); ?>

								<div class="col-md-1">
								<?php echo Form::checkbox('tracking[]', $number, '', ['onclick' => 'handleCheckbox(this)']); ?>

								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

						</div>	

						<label>Choose column:
							<select class="form-control" id="phil-ind-tracking-columns" name="phil-ind-tracking-columns">
								<option value="" selected="selected"></option>
				                <option value="date">Date</option>
				                <option value="direction">Direction</option>
				                <option value="status">Status</option>
				                <option value="tracking_local">Local tracking number</option>
				                <option value="pallet_number">Pallet number</option>
				                <option value="comments_1">Comments 1</option>
				                <option value="comments_2">Comments 2</option>
				                <option value="shipper_name">Shipper's name</option>
				                <option value="shipper_country">Shipper's country</option>
				                <option value="shipper_address">Shipper's address</option>
				                <option value="shipper_phone">Shipper's phone number</option>
				                <option value="shipper_id">Shipper's ID number</option>
				                <option value="consignee_name">Consignee's name</option>
				                <option value="consignee_country">Consignee's country</option>
				                <option value="consignee_address">Consignee's address</option>
				                <option value="consignee_phone">Consignee's phone number</option>
				                <option value="consignee_id">Consignee's ID number</option>
				                <option value="shipped_items">Shipped items</option>
				                <option value="shipment_val">Shipment's declared value</option>
				                <option value="operator">Operator</option>
				                <option value="courier">Courier</option>
				                <option value="delivery_date_comments">Pick-up/delivery date and comments</option>
				                <option value="weight">Weight</option>
				                <option value="width">Width</option>
				                <option value="height">Height</option>
				                <option value="length">Length</option>
				                <option value="volume_weight">Volume weight</option>
				                <option value="lot">Lot</option>
				                <option value="payment_date_comments">Payment date and comments</option>
				                <option value="amount_payment">Amount of payment</option>   
							</select>
						</label>	

						<label class="phil-ind-value-by-tracking">Input value:
							<input class="form-control" type="text" name="value-by-tracking">
							<input type="hidden" name="status_ru">
							<input type="hidden" name="status_he">
							<input type="hidden" name="shipper_country_val">
							<input type="hidden" name="consignee_country_val">
						</label>							

						<?php echo Form::button('Save',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::button('Cancel selection',['class'=>'btn btn-danger', 'onclick' => 'handleCencel()']); ?>

						<?php echo Form::close(); ?>


					</div>
				</div>
			</div>


		</div>
	</div><!-- .animated -->
</div><!-- .content -->


<?php else: ?>
<h1>You cannot view this page!</h1>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.phil_ind_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>