<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editEngDraft')): ?>

<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<div class="card-body">	

					<?php if(isset($courier_eng_draft_worksheet)): ?>				

						<?php echo Form::open(['url'=>route('courierEngDraftWorksheetUpdate', ['id'=>$courier_eng_draft_worksheet->id]), 'class'=>'form-horizontal china-worksheet-form phil-ind-update-form','method' => 'POST']); ?>


						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
						<?php
							$courier_eng_draft_worksheet->date = str_replace(".", "-", $courier_eng_draft_worksheet->date);
						?>
						<div class="form-group">
							<?php echo Form::label('date','Date',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::date('date',$courier_eng_draft_worksheet->date,['class' => 'form-control']); ?>

							</div>
						</div>
						<?php endif; ?>						

						<div class="form-group">
							<?php echo Form::label('status','Status',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('status', array('' => '', 'Pending' => 'Pending', 'Forwarding to the warehouse in the sender country' => 'Forwarding to the warehouse in the sender country', 'At the warehouse in the sender country' => 'At the warehouse in the sender country', 'At the customs in the sender country' => 'At the customs in the sender country', 'Forwarding to the receiver country' => 'Forwarding to the receiver country', 'At the customs in the receiver country' => 'At the customs in the receiver country', 'Forwarding to the receiver' => 'Forwarding to the receiver', 'Delivered' => 'Delivered', 'Return' => 'Return', 'Box' => 'Box', 'Pick up' => 'Pick up', 'Specify' => 'Specify', 'Think' => 'Think', 'Canceled' => 'Canceled'), $courier_eng_draft_worksheet->status,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
						<div class="form-group">
							<?php echo Form::label('status_date','Status date',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::date('status_date',$courier_eng_draft_worksheet->status_date,['class' => 'form-control']); ?>

							</div>
						</div>
						<?php endif; ?>						
						
						<div class="form-group">
							<?php echo Form::label('tracking_main','Main tracking number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('tracking_main',$courier_eng_draft_worksheet->tracking_main,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('parcels_qty','Parcels qty',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::number('parcels_qty',$courier_eng_draft_worksheet->parcels_qty,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('tracking_local','Local tracking number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('tracking_local',$courier_eng_draft_worksheet->tracking_local,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('pallet_number','Pallet number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('pallet_number',$courier_eng_draft_worksheet->pallet_number,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('comments_1','Comments 1',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('comments_1',$courier_eng_draft_worksheet->comments_1,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('comments_2','Comments 2',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('comments_2',$courier_eng_draft_worksheet->comments_2,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php if(!$courier_eng_draft_worksheet->getLastDocUniq()): ?>
						
						<div class="form-group">
							<?php echo Form::label('shipper_name','Shipper\'s name',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('shipper_name',$courier_eng_draft_worksheet->shipper_name,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('shipper_country','Shipper\'s country',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('shipper_country', array('Israel' => 'Israel', 'Germany' => 'Germany'), isset($courier_eng_draft_worksheet->shipper_country) ? $courier_eng_draft_worksheet->shipper_country : '',['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('shipper_city','Shipper\'s city/village',['class' => 'col-md-2 control-label']); ?>

							
							<?php if($courier_eng_draft_worksheet->shipper_country === 'Israel'): ?>

							<div class="col-md-4 choose-city-eng">
								<?php echo Form::select('choose_city_eng', ['0' => 'City change method', '1' => 'Select from the list (Region will be automatically determined)', '2' => 'Enter manually (Region may not be determined)'],'0',['class' => 'form-control']); ?>

							</div>
							
							<div class="col-md-4 choose-city-eng">
								<?php if(in_array($courier_eng_draft_worksheet->shipper_city, array_keys($israel_cities))): ?>
								
								<?php echo Form::select('shipper_city', $israel_cities, isset($courier_eng_draft_worksheet->shipper_city) ? $courier_eng_draft_worksheet->shipper_city : '',['class' => 'form-control']); ?>


								<?php echo Form::text('shipper_city',$courier_eng_draft_worksheet->shipper_city,['class' => 'form-control','style' => 'display:none','disabled' => 'disabled']); ?>

								
								<?php else: ?>

								<?php echo Form::select('shipper_city', $israel_cities, isset($courier_eng_draft_worksheet->shipper_city) ? $courier_eng_draft_worksheet->shipper_city : '',['class' => 'form-control','style' => 'display:none','disabled' => 'disabled']); ?>


								<?php echo Form::text('shipper_city',$courier_eng_draft_worksheet->shipper_city,['class' => 'form-control']); ?>


								<?php endif; ?>

							</div>

							<div class="col-md-8 choose-city-germany" style="display:none">	
								<?php echo Form::text('shipper_city',$courier_eng_draft_worksheet->shipper_city,['class' => 'form-control','disabled' => 'disabled']); ?>

							</div>
								
							<?php elseif($courier_eng_draft_worksheet->shipper_country === 'Germany'): ?>

							<div class="col-md-4 choose-city-eng" style="display:none">
								<?php echo Form::select('choose_city_eng', ['0' => 'City change method', '1' => 'Select from the list (Region will be automatically determined)', '2' => 'Enter manually (Region may not be determined)'],'0',['class' => 'form-control']); ?>

							</div>
							
							<div class="col-md-4 choose-city-eng" style="display:none">
								<?php if(in_array($courier_eng_draft_worksheet->shipper_city, array_keys($israel_cities))): ?>
								
								<?php echo Form::select('shipper_city', $israel_cities, isset($courier_eng_draft_worksheet->shipper_city) ? $courier_eng_draft_worksheet->shipper_city : '',['class' => 'form-control','disabled' => 'disabled']); ?>


								<?php echo Form::text('shipper_city',$courier_eng_draft_worksheet->shipper_city,['class' => 'form-control','style' => 'display:none','disabled' => 'disabled']); ?>

								
								<?php else: ?>

								<?php echo Form::select('shipper_city', $israel_cities, isset($courier_eng_draft_worksheet->shipper_city) ? $courier_eng_draft_worksheet->shipper_city : '',['class' => 'form-control','style' => 'display:none','disabled' => 'disabled']); ?>


								<?php echo Form::text('shipper_city',$courier_eng_draft_worksheet->shipper_city,['class' => 'form-control','disabled' => 'disabled']); ?>


								<?php endif; ?>

							</div>
							
							<div class="col-md-8 choose-city-germany">	
								<?php echo Form::text('shipper_city',$courier_eng_draft_worksheet->shipper_city,['class' => 'form-control']); ?>

							</div>	
								
							<?php endif; ?>
							
						</div>

						<div class="form-group">
							<?php echo Form::label('passport_number','GSTN/Passport number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('passport_number',$courier_eng_draft_worksheet->passport_number,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('return_date','Estimated return to India date',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('return_date',$courier_eng_draft_worksheet->return_date,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('shipper_address','Shipper\'s address',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('shipper_address',$courier_eng_draft_worksheet->shipper_address,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('standard_phone','Shipper\'s phone number (standard)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('standard_phone',$courier_eng_draft_worksheet->standard_phone,['class' => 'form-control standard-phone']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('shipper_phone','Shipper\'s phone number (additionally)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('shipper_phone',$courier_eng_draft_worksheet->shipper_phone,['class' => 'form-control']); ?>

							</div>
						</div>						

						<div class="form-group">
							<?php echo Form::label('shipper_id','Shipper\'s ID number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('shipper_id',$courier_eng_draft_worksheet->shipper_id,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_name','Consignee\'s name',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_name',$courier_eng_draft_worksheet->consignee_name,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_country','Consignee\'s country',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('consignee_country', array('India' => 'India', 'Nepal' => 'Nepal', 'Nigeria' => 'Nigeria', 'Ghana' => 'Ghana', 'Cote D\'Ivoire' => 'Cote D\'Ivoire', 'South Africa' => 'South Africa', 'Thailand' => 'Thailand'), isset($courier_eng_draft_worksheet->consignee_country) ? $courier_eng_draft_worksheet->consignee_country: '',['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('house_name','House name',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('house_name',$courier_eng_draft_worksheet->house_name,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('post_office','Local post office',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('post_office',$courier_eng_draft_worksheet->post_office,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('district','District/City',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('district',$courier_eng_draft_worksheet->district,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('state_pincode','State pincode',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('state_pincode',$courier_eng_draft_worksheet->state_pincode,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_address','Consignee\'s address',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_address',$courier_eng_draft_worksheet->consignee_address,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_phone','Consignee\'s phone number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_phone',$courier_eng_draft_worksheet->consignee_phone,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_id','Consignee\'s ID number',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_id',$courier_eng_draft_worksheet->consignee_id,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('shipped_items','Shipped items',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('shipped_items',$courier_eng_draft_worksheet->shipped_items,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('shipment_val','Shipment\'s declared value',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('shipment_val',$courier_eng_draft_worksheet->shipment_val,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php endif; ?>

						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

						<div class="form-group">
							<?php echo Form::label('operator','Operator',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('operator',$courier_eng_draft_worksheet->operator,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php endif; ?>

						<div class="form-group">
							<?php echo Form::label('courier','Courier',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('courier',$courier_eng_draft_worksheet->courier,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('delivery_date_comments','Pick-up/delivery date and comments',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('delivery_date_comments',$courier_eng_draft_worksheet->delivery_date_comments,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('weight','Weight',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('weight',$courier_eng_draft_worksheet->weight,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('width','Width',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('width',$courier_eng_draft_worksheet->width,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('height','Height',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('height',$courier_eng_draft_worksheet->height,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('length','Length',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('length',$courier_eng_draft_worksheet->length,['class' => 'form-control']); ?>

							</div>
						</div>
												
						<div class="form-group">
							<?php echo Form::label('volume_weight','Volume weight',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('volume_weight',$courier_eng_draft_worksheet->volume_weight,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('lot','Lot',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('lot',$courier_eng_draft_worksheet->lot,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('payment_date_comments','Payment date and comments',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('payment_date_comments',$courier_eng_draft_worksheet->payment_date_comments,['class' => 'form-control']); ?>

							</div>
						</div>
												
						<div class="form-group">
							<?php echo Form::label('amount_payment','Amount of payment',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('amount_payment',$courier_eng_draft_worksheet->amount_payment,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('status_ru_disabled','Status Ru',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_ru_disabled',$courier_eng_draft_worksheet->status_ru,['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_ru',$courier_eng_draft_worksheet->status_ru); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('status_he_disabled','Status He',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_he_disabled',$courier_eng_draft_worksheet->status_he,['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_he',$courier_eng_draft_worksheet->status_he); ?>

							</div>
						</div>																	

						<div class="form-group">
							<?php echo Form::label('consignee_name_customs','Consignee\'s name (for customs)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_name_customs',$courier_eng_draft_worksheet->consignee_name_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_address_customs','Consignee\'s address (for customs)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_address_customs',$courier_eng_draft_worksheet->consignee_address_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_phone_customs','Consignee\'s phone number (for customs)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_phone_customs',$courier_eng_draft_worksheet->consignee_phone_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('consignee_id_customs','Consignee\'s ID number (for customs)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('consignee_id_customs',$courier_eng_draft_worksheet->consignee_id_customs,['class' => 'form-control']); ?>

							</div>
						</div>

							<?php echo Form::hidden('id',$courier_eng_draft_worksheet->id); ?>


							<?php echo Form::hidden('shipper_region',$courier_eng_draft_worksheet->shipper_region); ?>


							<?php echo Form::hidden('in_trash',$courier_eng_draft_worksheet->in_trash); ?>


							<?php echo Form::hidden('parcels_qty',$courier_eng_draft_worksheet->parcels_qty); ?>


							<?php echo Form::hidden('date',$courier_eng_draft_worksheet->date,['class' => 'form-control']); ?>


							<?php echo Form::hidden('direction',$courier_eng_draft_worksheet->direction,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status',$courier_eng_draft_worksheet->status,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_date',$courier_eng_draft_worksheet->status_date); ?>


							<?php echo Form::hidden('tracking_main',$courier_eng_draft_worksheet->tracking_main,['class' => 'form-control']); ?>


							<?php echo Form::hidden('parcels_qty',$courier_eng_draft_worksheet->parcels_qty,['class' => 'form-control']); ?>


							<?php echo Form::hidden('order_number',$courier_eng_draft_worksheet->order_number); ?>


							<?php echo Form::hidden('tracking_local',$courier_eng_draft_worksheet->tracking_local,['class' => 'form-control']); ?>


							<?php echo Form::hidden('pallet_number',$courier_eng_draft_worksheet->pallet_number,['class' => 'form-control']); ?>


							<?php echo Form::hidden('comments_1',$courier_eng_draft_worksheet->comments_1,['class' => 'form-control']); ?>


							<?php echo Form::hidden('comments_2',$courier_eng_draft_worksheet->comments_2,['class' => 'form-control']); ?>


							<?php echo Form::hidden('shipper_name',$courier_eng_draft_worksheet->shipper_name,['class' => 'form-control']); ?>


							<?php echo Form::hidden('shipper_country',$courier_eng_draft_worksheet->shipper_country); ?>


							<?php echo Form::hidden('shipper_address',$courier_eng_draft_worksheet->shipper_address,['class' => 'form-control']); ?>


							<?php echo Form::hidden('standard_phone',$courier_eng_draft_worksheet->standard_phone,['class' => 'form-control']); ?>


							<?php echo Form::hidden('shipper_phone',$courier_eng_draft_worksheet->shipper_phone,['class' => 'form-control']); ?>


							<?php echo Form::hidden('shipper_id',$courier_eng_draft_worksheet->shipper_id,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_name',$courier_eng_draft_worksheet->consignee_name,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_country',$courier_eng_draft_worksheet->consignee_country); ?>


							<?php echo Form::hidden('consignee_address',$courier_eng_draft_worksheet->consignee_address,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_phone',$courier_eng_draft_worksheet->consignee_phone,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_id',$courier_eng_draft_worksheet->consignee_id,['class' => 'form-control']); ?>


							<?php echo Form::hidden('shipped_items',$courier_eng_draft_worksheet->shipped_items,['class' => 'form-control']); ?>


							<?php echo Form::hidden('shipment_val',$courier_eng_draft_worksheet->shipment_val,['class' => 'form-control']); ?>


							<?php echo Form::hidden('operator',$courier_eng_draft_worksheet->operator,['class' => 'form-control']); ?>


							<?php echo Form::hidden('courier',$courier_eng_draft_worksheet->courier,['class' => 'form-control']); ?>


							<?php echo Form::hidden('delivery_date_comments',$courier_eng_draft_worksheet->delivery_date_comments,['class' => 'form-control']); ?>


							<?php echo Form::hidden('weight',$courier_eng_draft_worksheet->weight,['class' => 'form-control']); ?>


							<?php echo Form::hidden('width',$courier_eng_draft_worksheet->width,['class' => 'form-control']); ?>


							<?php echo Form::hidden('height',$courier_eng_draft_worksheet->height,['class' => 'form-control']); ?>


							<?php echo Form::hidden('length',$courier_eng_draft_worksheet->length,['class' => 'form-control']); ?>


							<?php echo Form::hidden('volume_weight',$courier_eng_draft_worksheet->volume_weight,['class' => 'form-control']); ?>


							<?php echo Form::hidden('lot',$courier_eng_draft_worksheet->lot,['class' => 'form-control']); ?>


							<?php echo Form::hidden('payment_date_comments', $courier_eng_draft_worksheet->payment_date_comments,['class' => 'form-control']); ?>


							<?php echo Form::hidden('amount_payment',$courier_eng_draft_worksheet->amount_payment,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_ru',$courier_eng_draft_worksheet->status_ru,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_he',$courier_eng_draft_worksheet->status_he,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_name_customs',$courier_eng_draft_worksheet->consignee_name_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_address_customs',$courier_eng_draft_worksheet->consignee_address_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_phone_customs',$courier_eng_draft_worksheet->consignee_phone_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('consignee_id_customs',$courier_eng_draft_worksheet->consignee_id_customs,['class' => 'form-control']); ?>

					
						<?php echo Form::button('Save',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::close(); ?>


						<?php endif; ?>
					
					</div>
				</div>
			</div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<?php else: ?>
<h1>You cannot view this page!</h1>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.phil_ind_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>