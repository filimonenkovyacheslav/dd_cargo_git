<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editDraft')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<div class="card-body">	

					<?php if(isset($courier_draft_worksheet)): ?>				

						<?php echo Form::open(['url'=>route('courierDraftWorksheetUpdate', ['id'=>$courier_draft_worksheet->id]), 'class'=>'form-horizontal worksheet-update-form','method' => 'POST']); ?>


						<div class="form-group">
							<?php echo Form::label('site_name','Сайт',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('site_name', array('DD-C' => 'DD-C', 'For' => 'For'), $courier_draft_worksheet->site_name,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
						<?php
							$courier_draft_worksheet->date = str_replace(".", "-", $courier_draft_worksheet->date);
						?>
						<div class="form-group">
							<?php echo Form::label('date','Дата',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::date('date',$courier_draft_worksheet->date,['class' => 'form-control']); ?>

							</div>
						</div>
						<?php endif; ?>
						
						<div class="form-group">
							<?php echo Form::label('direction','Направление',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('direction',$courier_draft_worksheet->direction,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php if(!$courier_draft_worksheet->getLastDocUniq()): ?>
						
						<div class="form-group">
							<?php echo Form::label('tariff','Тариф',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('tariff', array('' => '', 'Море' => 'Море', 'Авиа' => 'Авиа'), $courier_draft_worksheet->tariff,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<?php endif; ?>
						
						<div class="form-group">
							<?php echo Form::label('status','Статус',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('status', array('' => '', 'Доставляется на склад в стране отправителя' => 'Доставляется на склад в стране отправителя', 'На складе в стране отправителя' => 'На складе в стране отправителя', 'На таможне в стране отправителя' => 'На таможне в стране отправителя', 'Доставляется в страну получателя' => 'Доставляется в страну получателя', 'На таможне в стране получателя' => 'На таможне в стране получателя', 'Доставляется получателю' => 'Доставляется получателю', 'Доставлено' => 'Доставлено', 'Возврат' => 'Возврат', 'Коробка' => 'Коробка', 'Забрать' => 'Забрать', 'Уточнить' => 'Уточнить', 'Думают' => 'Думают', 'Отмена' => 'Отмена'), $courier_draft_worksheet->status,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
						<div class="form-group">
							<?php echo Form::label('status_date','Дата статуса',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::date('status_date',$courier_draft_worksheet->status_date,['class' => 'form-control']); ?>

							</div>
						</div>
						<?php endif; ?>

						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
						<div class="form-group">
							<?php echo Form::label('order_date','Дата Заказа',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::date('order_date',$courier_draft_worksheet->order_date,['class' => 'form-control']); ?>

							</div>
						</div>
						<?php endif; ?>
						
						<div class="form-group">
							<?php echo Form::label('partner','Партнер',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('partner', array('' => '', 'viewer_1' => 'viewer_1', 'viewer_2' => 'viewer_2', 'viewer_3' => 'viewer_3', 'viewer_4' => 'viewer_4', 'viewer_5' => 'viewer_5'), $courier_draft_worksheet->partner,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('tracking_main','Трекинг Основной',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('tracking_main',$courier_draft_worksheet->tracking_main,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('parcels_qty','Кол-во посылок',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::number('parcels_qty',$courier_draft_worksheet->parcels_qty,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('tracking_local','Трекинг Локальные',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('tracking_local',$courier_draft_worksheet->tracking_local,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('tracking_transit','Трекинг Транзитные',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('tracking_transit',$courier_draft_worksheet->tracking_transit,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('pallet_number','№ паллеты',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('pallet_number',$courier_draft_worksheet->pallet_number,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('comment_2','OFF Коммент',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('comment_2',$courier_draft_worksheet->comment_2,['class' => 'form-control']); ?>

							</div>
						</div>						

						<div class="form-group">
							<?php echo Form::label('comments','DIR Комментарии',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('comments',$courier_draft_worksheet->comments,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php if(!$courier_draft_worksheet->getLastDocUniq()): ?>
						
						<div class="form-group">
							<?php echo Form::label('sender_name','Отправитель',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('sender_name',$courier_draft_worksheet->sender_name,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('sender_country','Страна отправителя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('sender_country',$courier_draft_worksheet->sender_country,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('sender_city','Город отправителя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-4">
								<?php echo Form::select('choose_city_ru', ['0' => 'Метод изменения города', '1' => 'Выбрать из списка (автоматически определится Регион)', '2' => 'Ввести вручную (Регион возможно не определится)'],'0',['class' => 'form-control']); ?>

							</div>
							<div class="col-md-4 choose-city-ru">
								<?php if(in_array($courier_draft_worksheet->sender_city, array_keys($israel_cities))): ?>
								
								<?php echo Form::select('sender_city', $israel_cities, isset($courier_draft_worksheet->sender_city) ? $courier_draft_worksheet->sender_city : '',['class' => 'form-control']); ?>


								<?php echo Form::text('sender_city',$courier_draft_worksheet->sender_city,['class' => 'form-control','style' => 'display:none','disabled' => 'disabled']); ?>

								
								<?php else: ?>

								<?php echo Form::select('sender_city', $israel_cities, isset($courier_draft_worksheet->sender_city) ? $courier_draft_worksheet->sender_city : '',['class' => 'form-control','style' => 'display:none','disabled' => 'disabled']); ?>


								<?php echo Form::text('sender_city',$courier_draft_worksheet->sender_city,['class' => 'form-control']); ?>


								<?php endif; ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('sender_postcode','Индекс отправителя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('sender_postcode',$courier_draft_worksheet->sender_postcode,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('sender_address','Адрес отправителя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('sender_address',$courier_draft_worksheet->sender_address,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('standard_phone','Телефон отправителя (стандарт)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('standard_phone',$courier_draft_worksheet->standard_phone,['class' => 'form-control standard-phone']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('sender_phone','Телефон отправителя (дополнительно)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('sender_phone',$courier_draft_worksheet->sender_phone,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('sender_passport','Номер паспорта отправителя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('sender_passport',$courier_draft_worksheet->sender_passport,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_name','Получатель',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_name',$courier_draft_worksheet->recipient_name,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_country','Страна получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_country',$courier_draft_worksheet->recipient_country,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('region','Регион',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('region',$courier_draft_worksheet->region,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('district','Район',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('district',$courier_draft_worksheet->district,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_city','Город получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_city',$courier_draft_worksheet->recipient_city,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_postcode','Индекс получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_postcode',$courier_draft_worksheet->recipient_postcode,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_street','Улица получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_street',$courier_draft_worksheet->recipient_street,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_house','Номер дома получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_house',$courier_draft_worksheet->recipient_house,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('body','корпус',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('body',$courier_draft_worksheet->body,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_room','Номер квартиры получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_room',$courier_draft_worksheet->recipient_room,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_phone','Телефон получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_phone',$courier_draft_worksheet->recipient_phone,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php endif; ?>
						
						<div class="form-group">
							<?php echo Form::label('recipient_passport','Номер паспорта получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_passport',$courier_draft_worksheet->recipient_passport,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_email','E-mail получателя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_email',$courier_draft_worksheet->recipient_email,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php if(!$courier_draft_worksheet->getLastDocUniq()): ?>
						
						<div class="form-group">
							<?php echo Form::label('package_content','Содержимое посылки',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('package_content',$courier_draft_worksheet->package_content,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('package_cost','Декларируемая стоимость посылки',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('package_cost',$courier_draft_worksheet->package_cost,['class' => 'form-control']); ?>

							</div>
						</div>

						<?php endif; ?>
						
						<div class="form-group">
							<?php echo Form::label('courier','Курьер',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('courier',$courier_draft_worksheet->courier,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('pick_up_date','Дата забора и комментарии',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('pick_up_date',$courier_draft_worksheet->pick_up_date,['class' => 'form-control']); ?>

							</div>
						</div>
						
						<div class="form-group">
							<?php echo Form::label('weight','Вес посылки',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('weight',$courier_draft_worksheet->weight,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('width','Ширина',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('width',$courier_draft_worksheet->width,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('height','Высота',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('height',$courier_draft_worksheet->height,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('length','Длина',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('length',$courier_draft_worksheet->length,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('volume_weight','Объемный вес',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('volume_weight',$courier_draft_worksheet->volume_weight,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('quantity_things','Кол-во предметов',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('quantity_things',$courier_draft_worksheet->quantity_things,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('batch_number','Партия',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('batch_number',$courier_draft_worksheet->batch_number,['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('pay_date','Дата оплаты и комментарии',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('pay_date',$courier_draft_worksheet->pay_date,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('pay_sum','Сумма оплаты',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('pay_sum',$courier_draft_worksheet->pay_sum,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('status_en_disabled','Статус (ENG)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_en_disabled',$courier_draft_worksheet->status_en,['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_en',$courier_draft_worksheet->status_en,[]); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('status_he_disabled','Статус (HE)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_he_disabled',$courier_draft_worksheet->status_he,['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_he',$courier_draft_worksheet->status_he,[]); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('status_ua_disabled','Статус (UA)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_ua_disabled',$courier_draft_worksheet->status_ua,['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_ua',$courier_draft_worksheet->status_ua,[]); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_name_customs','Получатель (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_name_customs',$courier_draft_worksheet->recipient_name_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_country_customs','Страна получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_country_customs',$courier_draft_worksheet->recipient_country_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_city_customs','Город получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_city_customs',$courier_draft_worksheet->recipient_city_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_postcode_customs','Индекс получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_postcode_customs',$courier_draft_worksheet->recipient_postcode_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_street_customs','Улица получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_street_customs',$courier_draft_worksheet->recipient_street_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_house_customs','Номер дома получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_house_customs',$courier_draft_worksheet->recipient_house_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_room_customs','Номер квартиры получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_room_customs',$courier_draft_worksheet->recipient_room_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_phone_customs','Телефон получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_phone_customs',$courier_draft_worksheet->recipient_phone_customs,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('recipient_passport_customs','Номер паспорта получателя (для таможни)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('recipient_passport_customs',$courier_draft_worksheet->recipient_passport_customs,['class' => 'form-control']); ?>

							</div>
						</div>

							<?php echo Form::hidden('id',$courier_draft_worksheet->id); ?>


							<?php echo Form::hidden('shipper_region',$courier_draft_worksheet->shipper_region); ?>


							<?php echo Form::hidden('in_trash',$courier_draft_worksheet->in_trash); ?>


							<?php echo Form::hidden('parcels_qty',$courier_draft_worksheet->parcels_qty); ?>


							<?php echo Form::hidden('site_name',$courier_draft_worksheet->site_name,['class' => 'form-control']); ?>


							<?php echo Form::hidden('date',$courier_draft_worksheet->date,['class' => 'form-control']); ?>


							<?php echo Form::hidden('direction',$courier_draft_worksheet->direction,['class' => 'form-control']); ?>


							<?php echo Form::hidden('tariff',$courier_draft_worksheet->tariff,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status',$courier_draft_worksheet->status,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_date',$courier_draft_worksheet->status_date); ?>


							<?php echo Form::hidden('order_date',$courier_draft_worksheet->order_date); ?>


							<?php echo Form::hidden('partner',$courier_draft_worksheet->partner,['class' => 'form-control']); ?>


							<?php echo Form::hidden('tracking_main',$courier_draft_worksheet->tracking_main,['class' => 'form-control']); ?>


							<?php echo Form::hidden('order_number',$courier_draft_worksheet->order_number); ?>


							<?php echo Form::hidden('tracking_local',$courier_draft_worksheet->tracking_local,['class' => 'form-control']); ?>


							<?php echo Form::hidden('tracking_transit',$courier_draft_worksheet->tracking_transit,['class' => 'form-control']); ?>


							<?php echo Form::hidden('pallet_number',$courier_draft_worksheet->pallet_number,['class' => 'form-control']); ?>


							<?php echo Form::hidden('comment_2',$courier_draft_worksheet->comment_2,['class' => 'form-control']); ?>


							<?php echo Form::hidden('comments',$courier_draft_worksheet->comments,['class' => 'form-control']); ?>


							<?php echo Form::hidden('sender_name',$courier_draft_worksheet->sender_name,['class' => 'form-control']); ?>


							<?php echo Form::hidden('sender_country',$courier_draft_worksheet->sender_country,['class' => 'form-control']); ?>


							<?php echo Form::hidden('sender_city',$courier_draft_worksheet->sender_city,['class' => 'form-control']); ?>


							<?php echo Form::hidden('sender_postcode',$courier_draft_worksheet->sender_postcode,['class' => 'form-control']); ?>


							<?php echo Form::hidden('sender_address',$courier_draft_worksheet->sender_address,['class' => 'form-control']); ?>


							<?php echo Form::hidden('standard_phone',$courier_draft_worksheet->standard_phone); ?>


							<?php echo Form::hidden('sender_phone',$courier_draft_worksheet->sender_phone,['class' => 'form-control']); ?>


							<?php echo Form::hidden('sender_passport',$courier_draft_worksheet->sender_passport,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_name',$courier_draft_worksheet->recipient_name,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_country',$courier_draft_worksheet->recipient_country,['class' => 'form-control']); ?>


							<?php echo Form::hidden('region',$courier_draft_worksheet->region); ?>


							<?php echo Form::hidden('district',$courier_draft_worksheet->district); ?>


							<?php echo Form::hidden('recipient_city',$courier_draft_worksheet->recipient_city,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_postcode',$courier_draft_worksheet->recipient_postcode,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_street',$courier_draft_worksheet->recipient_street,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_house',$courier_draft_worksheet->recipient_house,['class' => 'form-control']); ?>


							<?php echo Form::hidden('body',$courier_draft_worksheet->body); ?>


							<?php echo Form::hidden('recipient_room',$courier_draft_worksheet->recipient_room,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_phone',$courier_draft_worksheet->recipient_phone,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_passport',$courier_draft_worksheet->recipient_passport,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_email',$courier_draft_worksheet->recipient_email,['class' => 'form-control']); ?>


							<?php echo Form::hidden('package_content',$courier_draft_worksheet->package_content,['class' => 'form-control']); ?>


							<?php echo Form::hidden('package_cost',$courier_draft_worksheet->package_cost,['class' => 'form-control']); ?>


							<?php echo Form::hidden('courier',$courier_draft_worksheet->courier,['class' => 'form-control']); ?>


							<?php echo Form::hidden('pick_up_date',$courier_draft_worksheet->pick_up_date,['class' => 'form-control']); ?>


							<?php echo Form::hidden('weight',$courier_draft_worksheet->weight,['class' => 'form-control']); ?>


							<?php echo Form::hidden('width',$courier_draft_worksheet->width,['class' => 'form-control']); ?>


							<?php echo Form::hidden('height',$courier_draft_worksheet->height,['class' => 'form-control']); ?>


							<?php echo Form::hidden('length',$courier_draft_worksheet->length,['class' => 'form-control']); ?>


							<?php echo Form::hidden('volume_weight',$courier_draft_worksheet->volume_weight,['class' => 'form-control']); ?>


							<?php echo Form::hidden('quantity_things',$courier_draft_worksheet->quantity_things,['class' => 'form-control']); ?>


							<?php echo Form::hidden('batch_number',$courier_draft_worksheet->batch_number,['class' => 'form-control']); ?>


							<?php echo Form::hidden('pay_date',$courier_draft_worksheet->pay_date,['class' => 'form-control']); ?>


							<?php echo Form::hidden('pay_sum',$courier_draft_worksheet->pay_sum,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_en',$courier_draft_worksheet->status_en,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_he',$courier_draft_worksheet->status_he,['class' => 'form-control']); ?>


							<?php echo Form::hidden('status_ua',$courier_draft_worksheet->status_ua,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_name_customs',$courier_draft_worksheet->recipient_name_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_country_customs',$courier_draft_worksheet->recipient_country_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_city_customs',$courier_draft_worksheet->recipient_city_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_postcode_customs',$courier_draft_worksheet->recipient_postcode_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_street_customs',$courier_draft_worksheet->recipient_street_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_house_customs',$courier_draft_worksheet->recipient_house_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_room_customs',$courier_draft_worksheet->recipient_room_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_phone_customs',$courier_draft_worksheet->recipient_phone_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('recipient_passport_customs',$courier_draft_worksheet->recipient_passport_customs,['class' => 'form-control']); ?>


							<?php echo Form::hidden('update_status_date',$courier_draft_worksheet->update_status_date); ?>							
					
						<?php echo Form::button('Сохранить',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::close(); ?>


						<?php endif; ?>
					
					</div>
				</div>
			</div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<?php else: ?>
<h1>Вы не можете просматривать эту страницу!</h1>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>