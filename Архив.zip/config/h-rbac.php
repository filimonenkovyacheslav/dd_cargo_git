<?php return [
    
    /*
    |--------------------------------------------------------------------------
    | Package Configuration Option
    |--------------------------------------------------------------------------
    | Describe what it does. 
    */

    'rbacClass' => App\Classes\Authorization\AuthorizationClass::class,

];
