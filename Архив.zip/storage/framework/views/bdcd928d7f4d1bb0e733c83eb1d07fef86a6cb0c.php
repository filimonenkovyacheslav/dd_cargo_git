<?php $__env->startSection('content'); ?>

<center>

<?php if(isset($_GET['new_document_id'])): ?>
<div class="alert alert-success  alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">×</button>  
    <strong>File <?php echo e($_GET['pdf_file']); ?> signed and saved successfully</strong>
    <a href="<?php echo e(url('/download-pdf/'.$_GET['new_document_id'])); ?>">Download PDF</a>
    <?php if(isset($_GET['old_file'])): ?>
    <strong>Old document file <?php echo e($_GET['old_file']); ?></strong>
    <?php endif; ?>
</div>
<?php endif; ?>

</center>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.front_signature_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>