<?php $__env->startSection('content'); ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<a href="<?php echo e(route('exportExcelInvoice')); ?>" style="margin-bottom: 20px;" class="btn btn-success btn-move">Экспорт в Excel</a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>

					<?php if(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<?php
						session(['this_previous_url' => url()->full()]);
					?>					

					<div class="btn-move-wrapper" style="display:flex">
						<form action="<?php echo e(route('invoiceFilter')); ?>" method="GET" id="form-worksheet-table-filter" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<label class="table_columns" style="margin: 0 15px">Выберите колонку:
								<select class="form-control" id="table_columns" name="table_columns">
									<option value="" selected="selected"></option>
									<option value="tracking">TRACKING</option>
									<option value="shipper_name">Shipper name</option>
									<option value="shipper_address_phone">Shipper address, phone</option>
									<option value="consignee_name">Consignee name</option>
									<option value="consignee_address">Consignee address</option> 
									<option value="shipped_items">Shipped items</option>
									<option value="weight">Parcel weight, kg</option>
									<option value="height">Parcel height, cm</option>
									<option value="length">Parcel length, cm</option>
									<option value="width">Parcel width, cm</option>
									<option value="declared_value">Declared value</option>  
									<option value="batch_number">Lot</option>           
								</select>
							</label>
							<label>Фильтр:
								<input type="search" name="table_filter_value" class="form-control form-control-sm">
							</label>
							<button type="button" id="table_filter_button" style="margin-left:35px" class="btn btn-default">Искать</button>
						</form>
					</div>
					
					<div class="card-body new-worksheet">
						<div class="table-container">
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>№</th>
										<th>TRACKING</th>
										<th>BOX</th>
										<th>Shipper name</th>
										<th>Shipper address, phone</th>
										<th>Consignee name</th> 
										<th>Consignee address</th>
										<th>Shipped items</th>
										<th>Parcel weight, kg</th>
										<th>Parcel height, cm</th>
										<th>Parcel length, cm</th>
										<th>Parcel width, cm</th>
										<th>Declared value</th>
										<th>Lot</th>
									</tr>
								</thead>
								<tbody>

									<?php if(isset($invoice_obj)): ?>
									<?php $__currentLoopData = $invoice_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td title="<?php echo e($row->number); ?>">
											<div class="div-number"><?php echo e($row->number); ?></div>
										</td>
										<td title="<?php echo e($row->tracking); ?>">
											<div class="div-3"><?php echo e($row->tracking); ?></div>
										</td>
										<td title="<?php echo e($row->box); ?>">
											<div class="div-number"><?php echo e($row->box); ?></div>
										</td>
										<td title="<?php echo e($row->shipper_name); ?>">
											<div class="div-10"><?php echo e($row->shipper_name); ?></div>
										</td>
										<td title="<?php echo e($row->shipper_address_phone); ?>">
											<div class="div-invoice"><?php echo e($row->shipper_address_phone); ?></div>
										</td>
										<td title="<?php echo e($row->consignee_name); ?>">
											<div class="div-10"><?php echo e($row->consignee_name); ?></div>
										</td>
										<td title="<?php echo e($row->consignee_address); ?>">
											<div class="div-invoice"><?php echo e($row->consignee_address); ?></div>
										</td>
										<td title="<?php echo e($row->shipped_items); ?>">
											<div class="div-invoice"><?php echo e($row->shipped_items); ?></div>
										</td>
										<td title="<?php echo e($row->weight); ?>">
											<div class="div-number"><?php echo e($row->weight); ?></div>
										</td>
										<td title="<?php echo e($row->height); ?>">
											<div class="div-number"><?php echo e($row->height); ?></div>
										</td>
										<td title="<?php echo e($row->length); ?>">
											<div class="div-number"><?php echo e($row->length); ?></div>
										</td>
										<td title="<?php echo e($row->width); ?>">
											<div class="div-number"><?php echo e($row->width); ?></div>
										</td>
										<td title="<?php echo e($row->declared_value); ?>">
											<div class="div-number"><?php echo e($row->declared_value); ?></div>
										</td>
										<td title="<?php echo e($row->batch_number); ?>">
											<div class="div-3"><?php echo e($row->batch_number); ?></div>
										</td>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>

							<?php if(isset($data)): ?>
							<?php echo e($invoice_obj->appends($data)->links()); ?>

							<?php else: ?>
							<?php echo e($invoice_obj->links()); ?>

							<?php endif; ?>
						
						</div>
					</div>
				</div>
			</div><!-- .col-md-12 -->
		</div><!-- .row -->		
		
	</div><!-- .animated -->
</div><!-- .content -->

<script>

	function ConfirmDelete()
	{
		var x = confirm("Вы уверены, что хотите удалить?");
		if (x)
			return true;
		else
			return false;
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>