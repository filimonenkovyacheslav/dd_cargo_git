<?php $__env->startSection('content'); ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<a href="<?php echo e(route('exportExcel')); ?>" style="margin-bottom: 20px;" class="btn btn-success btn-move">Экспорт в Excel</a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<!-- <div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div> -->

					<?php if(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<div class="card-body worksheet">
						<div class="table-container">
							<table id="bootstrap-data-table" class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>Номер</th>
										<th>Дата
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
											<a class="btn btn-primary" target="_blank" href="<?php echo e(url('/admin/worksheet/date')); ?>">Изменить</a>
											<?php endif; ?>
										</th>
										<th>Направление</th>
										<th>Статус</th>
										<th>Локальный</th>
										<th>Трекинг</th>
										<th>Коммент менеджера</th>
										<th>Коммент</th>
										<th>Комментарии</th>
										<th>Отправитель</th>
										<th>Данные отправителя</th>
										<th>Получатель</th>
										<th>Данные получателя</th>
										<th>E-mail получателя</th>
										<th>Декларируемая стоимость посылки, $</th>
										<th>Упаковка</th>
										<th>Оплачивает посылку</th>
										<th>Трекинг номер и вес посылки</th>
										<th>Ширина</th>
										<th>Высота</th>
										<th>Длина</th>
										<th>Номер партии
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
											<a class="btn btn-primary" target="_blank" href="<?php echo e(url('/admin/worksheet/batch-number')); ?>">Изменить</a>
											<?php endif; ?>
										</th>
										<th>Тип отправления</th>
										<th>Описание содержимого посылки</th>
										<th>1. позиция: описание количество цена,$</th>
										<th>2. позиция: описание количество цена,$</th>
										<th>3. позиция</th>
										<th>4. позиция</th>
										<th>5. позиция</th>
										<th>6. позиция</th>
										<th>7. позиция</th>
										<th>ENG</th>
										<th>RU</th>
										<th>HE</th>
										<th>UA</th>
										<th>Оплата</th>
										<th>Физ. вес</th>
										<th>Объем. вес</th>
										<th>К-во ед</th>
										<th>Комментарии</th>
										<th>Себестоимость</th>
										<th>Стоимость доставки из Украины</th>
										<th>Изменить</th>
									</tr>
								</thead>
								<tbody>
									
									<?php if(isset($worksheet_obj)): ?>
									<?php $__currentLoopData = $worksheet_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
									<tr>
										<td><?php echo e($row->num_row); ?></td>
										<td><?php echo e($row->date); ?></td>
										<td><?php echo e($row->direction); ?></td>
										<td><?php echo e($row->status); ?></td>
										<td><?php echo e($row->local); ?></td>
										<td><?php echo e($row->tracking); ?></td>
										<td><?php echo e($row->manager_comments); ?></td>
										<td><?php echo e($row->comment); ?></td>
										<td><?php echo e($row->comments); ?></td>
										<td><?php echo e($row->sender); ?></td>
										<td><?php echo e($row->data_sender); ?></td>
										<td><?php echo e($row->recipient); ?></td>
										<td><?php echo e($row->data_recipient); ?></td>
										<td><?php echo e($row->email_recipient); ?></td>
										<td><?php echo e($row->parcel_cost); ?></td>
										<td><?php echo e($row->packaging); ?></td>
										<td><?php echo e($row->pays_parcel); ?></td>
										<td><?php echo e($row->number_weight); ?></td>
										<td><?php echo e($row->width); ?></td>
										<td><?php echo e($row->height); ?></td>
										<td><?php echo e($row->length); ?></td>
										<td><?php echo e($row->batch_number); ?></td>
										<td><?php echo e($row->shipment_type); ?></td>
										<td><?php echo e($row->parcel_description); ?></td>
										<td><?php echo e($row->position_1); ?></td>
										<td><?php echo e($row->position_2); ?></td>
										<td><?php echo e($row->position_3); ?></td>
										<td><?php echo e($row->position_4); ?></td>
										<td><?php echo e($row->position_5); ?></td>
										<td><?php echo e($row->position_6); ?></td>
										<td><?php echo e($row->position_7); ?></td>
										<td><?php echo e($row->guarantee_text_en); ?></td>
										<td><?php echo e($row->guarantee_text_ru); ?></td>
										<td><?php echo e($row->guarantee_text_he); ?></td>
										<td><?php echo e($row->guarantee_text_ua); ?></td>
										<td><?php echo e($row->payment); ?></td>
										<td><?php echo e($row->phys_weight); ?></td>
										<td><?php echo e($row->volume_weight); ?></td>
										<td><?php echo e($row->quantity); ?></td>
										<td><?php echo e($row->comments_2); ?></td>
										<td><?php echo e($row->cost_price); ?></td>
										<td><?php echo e($row->shipment_cost); ?></td> 
										<td class="td-button">
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
											<a class="btn btn-primary" href="<?php echo e(url('/admin/worksheet-update/'.$row->id)); ?>">Изменить</a>

											<?php echo Form::open(['url'=>route('deleteWorksheet'),'onsubmit' => 'return ConfirmDelete()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('action',$row->id); ?>

											<?php echo Form::button('Удалить',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<?php endif; ?>
										</td>                              
									</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>		
	
	</div><!-- .animated -->
</div><!-- .content -->

<script>

	function ConfirmDelete()
	{
		var x = confirm("Вы уверены, что хотите удалить?");
		if (x)
			return true;
		else
			return false;
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>