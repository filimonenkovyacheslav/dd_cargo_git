<?php $__env->startSection('content'); ?>

<?php
if($type === 'draft_id' || $type === 'worksheet_id') $ru = true;
else $ru = false;
?>

<center>

<?php echo Form::open(['url'=>route('signatureForCancel'), 'class'=>'form-horizontal','method' => 'GET']); ?>


<?php echo Form::hidden('type',$type); ?>

<?php echo Form::hidden('id',$worksheet->id); ?>


<?php if($ru): ?>
<h4 style="margin: 50px auto; width: 300px">
	<img src="<?php echo e(asset('/images/cancel_img_1.png')); ?>">
<?php echo e($worksheet->getLastDocUniq()); ?>

<?php if($worksheet->tracking_main): ?>
<img src="<?php echo e(asset('/images/cancel_img_2.png')); ?>">
<?php echo e($worksheet->tracking_main); ?>

<?php endif; ?>
</h4>
<br>
<label for="create_new">ЗАПОЛНИТЬ ЗАНОВО</label>
<?php elseif(!$ru): ?>
<h4 style="margin: 50px auto; width: 300px"><?php echo e($message); ?></h4>
<br>
<label for="create_new">FILL AGAIN</label>
<?php endif; ?>

<input type="checkbox" id="create_new" name="create_new">
<br>

<?php echo Form::button( ($ru) ? 'Подписать' : 'To sign',['class'=>'btn btn-primary','type'=>'submit']); ?>

<?php echo Form::close(); ?> 

</center>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.front_signature_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>