<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<div class="card-body">					

						<?php echo Form::open(['url'=>route('addNewData'), 'class'=>'form-horizontal worksheet-add-form','method' => 'POST']); ?>


						<?php echo Form::button('Сохранить',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::button('Отменить выделение',['class'=>'btn btn-danger', 'onclick' => 'handleCencel()']); ?>						

						<div id="checkbox-group">

						<?php $__currentLoopData = $date_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
							<div class="form-group">
							<?php echo Form::label('tracking[]', $number,['class' => 'col-md-2 control-label']); ?>

								<div class="col-md-1">
								<?php echo Form::checkbox('tracking[]', $number, '', ['onclick' => 'handleCheckbox(this)']); ?>

								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

						</div>	

						<label>Выберите колонку:
							<select class="form-control" id="tracking-columns" name="tracking-columns">
								<option value="" selected="selected"></option>
								<option value="site_name">Сайт</option>
								<option value="date">Дата</option>
								<option value="direction">Направление</option>
								<option value="tariff">Тариф</option>
								<option value="status">Статус</option>
								<option value="partner">Партнер</option>
								<option value="tracking_local">Локальный</option>
								<option value="tracking_transit">Транзитный</option>
								<option value="pallet_number">Номер паллеты</option>
								<option value="comment_2">Коммент</option>
								<option value="comments">Комментарии</option>
								<option value="sender_name">Отправитель</option>
								<option value="sender_country">Страна отправителя</option>
								<option value="sender_city">Город отправителя</option>
								<option value="sender_postcode">Индекс отправителя</option>
								<option value="sender_address">Адрес отправителя</option>
								<option value="sender_phone">Телефон отправителя</option>
								<option value="sender_passport">Номер паспорта отправителя</option>
								<option value="recipient_name">Получатель</option>
								<option value="recipient_country">Страна получателя</option>
								<option value="region">Регион</option>
								<option value="district">Район</option>
								<option value="recipient_city">Город получателя</option>
								<option value="recipient_postcode">Индекс получателя</option>
								<option value="recipient_street">Улица получателя</option>
								<option value="recipient_house">№ дома пол-ля</option>
								<option value="body">корпус</option>
								<option value="recipient_room">№ кв. пол-ля</option>
								<option value="recipient_phone">Телефон получателя</option>
								<option value="recipient_passport">Номер паспорта получателя</option>
								<option value="recipient_email">E-mail получателя</option>
								<option value="package_cost">Стоимость посылки</option>
								<option value="courier">Курьер</option>
								<option value="pick_up_date">Дата забора и комментарии</option>
								<option value="weight">Вес посылки</option>
								<option value="width">Ширина</option>
								<option value="height">Высота</option>
								<option value="length">Длина</option>
								<option value="volume_weight">Объемный вес</option>
								<option value="quantity_things">Кол-во предметов</option>
								<option value="batch_number">Партия</option>
								<option value="pay_date">Дата оплаты и комментарии</option>
								<option value="pay_sum">Сумма оплаты</option>  
							</select>
						</label>	

						<label class="value-by-tracking">Введите значение:
							<input class="form-control" type="text" name="value-by-tracking">
							<input type="hidden" name="status_en">
							<input type="hidden" name="status_ua">
							<input type="hidden" name="status_he">
						</label>							

						<?php echo Form::button('Сохранить',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::button('Отменить выделение',['class'=>'btn btn-danger', 'onclick' => 'handleCencel()']); ?>

						<?php echo Form::close(); ?>


					</div>
				</div>
			</div>


		</div>
	</div><!-- .animated -->
</div><!-- .content -->


<?php else: ?>
<h1>Вы не можете просматривать эту страницу!</h1>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>