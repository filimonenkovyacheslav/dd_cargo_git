<?php $__env->startSection('content'); ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<a href="<?php echo e(route('exportExcelManifest')); ?>" style="margin-bottom: 20px;" class="btn btn-success btn-move">Экспорт в Excel</a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>

					<?php if(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<?php
						session(['this_previous_url' => url()->full()]);
					?>					

					<div class="btn-move-wrapper" style="display:flex">
						<form action="<?php echo e(route('manifestFilter')); ?>" method="GET" id="form-worksheet-table-filter" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<label class="table_columns" style="margin: 0 15px">Выберите колонку:
								<select class="form-control" id="table_columns" name="table_columns">
									<option value="" selected="selected"></option>
									<option value="tracking">TRACKING</option>
									<option value="sender_country">Sender country</option>
									<option value="sender_name">Sender company</option>
									<option value="recipient_name">Recipient</option>  
									<option value="recipient_city">Recipient city</option>
									<option value="recipient_address">Recipient address</option> 
									<option value="content">Description ENG</option>
									<option value="quantity">Quantity</option> 
									<option value="weight">Weight of item (kg)</option>
									<option value="cost">Customs Cost of item (USD)</option> 
									<option value="batch_number">Lot</option>             
								</select>
							</label>
							<label>Фильтр:
								<input type="search" name="table_filter_value" class="form-control form-control-sm">
							</label>
							<button type="button" id="table_filter_button" style="margin-left:35px" class="btn btn-default">Искать</button>
						</form>
					</div>
					
					<div class="card-body new-worksheet">
						<div class="table-container">
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>№</th>
										<th>TRACKING</th>
										<th>Sender country</th>
										<th>Sender company</th>
										<th>Recipient</th> 
										<th>Recipient city</th>
										<th>Recipient address</th>
										<th>Description ENG</th>
										<th>Quantity</th>
										<th>Weight of item (kg)</th>
										<th>Customs Cost of item (USD)</th>
										<th>Lot</th>
									</tr>
								</thead>
								<tbody>

									<?php if(isset($manifest_obj)): ?>
									<?php $__currentLoopData = $manifest_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td title="<?php echo e($row->number); ?>">
											<div class="div-number"><?php echo e($row->number); ?></div>
										</td>
										<td title="<?php echo e($row->tracking); ?>">
											<div class="div-3"><?php echo e($row->tracking); ?></div>
										</td>
										<td title="<?php echo e($row->sender_country); ?>">
											<div class="div-3"><?php echo e($row->sender_country); ?></div>
										</td>
										<td title="<?php echo e($row->sender_name); ?>">
											<div class="div-3"><?php echo e($row->sender_name); ?></div>
										</td>
										<td title="<?php echo e($row->recipient_name); ?>">
											<div class="div-3"><?php echo e($row->recipient_name); ?></div>
										</td>
										<td title="<?php echo e($row->recipient_city); ?>">
											<div class="div-3"><?php echo e($row->recipient_city); ?></div>
										</td>
										<td title="<?php echo e($row->recipient_address); ?>">
											<div class="div-3"><?php echo e($row->recipient_address); ?></div>
										</td>
										<td title="<?php echo e($row->content); ?>">
											<div class="div-3"><?php echo e($row->content); ?></div>
										</td>
										<td title="<?php echo e($row->quantity); ?>">
											<div class="div-number"><?php echo e($row->quantity); ?></div>
										</td>
										<td title="<?php echo e($row->weight); ?>">
											<div class="div-number"><?php echo e($row->weight); ?></div>
										</td>
										<td title="<?php echo e($row->cost); ?>">
											<div class="div-number"><?php echo e($row->cost); ?></div>
										</td>
										<td title="<?php echo e($row->batch_number); ?>">
											<div class="div-3"><?php echo e($row->batch_number); ?></div>
										</td>
									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>

							<?php if(isset($data)): ?>
							<?php echo e($manifest_obj->appends($data)->links()); ?>

							<?php else: ?>
							<?php echo e($manifest_obj->links()); ?>

							<?php endif; ?>
						
						</div>
					</div>
				</div>
			</div><!-- .col-md-12 -->
		</div><!-- .row -->		
		
	</div><!-- .animated -->
</div><!-- .content -->

<script>

	function ConfirmDelete()
	{
		var x = confirm("Вы уверены, что хотите удалить?");
		if (x)
			return true;
		else
			return false;
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>