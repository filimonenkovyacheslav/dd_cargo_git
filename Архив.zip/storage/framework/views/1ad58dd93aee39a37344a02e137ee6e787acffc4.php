<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-2')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Control Panel</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminPhilIndIndex')); ?>">Control Panel</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->

<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>

					<?php if(session('status-error')): ?>
					<div class="alert alert-danger">
						<?php echo e(session('status-error')); ?>

					</div>
					<?php elseif(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<?php
						session(['this_previous_url' => url()->full()]);
					?>
					
					<a class="btn" id="run-modal" data-toggle="modal" data-target="#warehouseRunModal"></a>
					<a class="btn" id="add-tracking" data-toggle="modal" data-target="#warehouseAddTracking"></a>
					
					<div class="card-body new-worksheet">
						<div class="table-container">
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>TRACKING NO.</th>
										<th>CHANGE</th>
										<th>NOTIFICATIONS</th>
									</tr>
								</thead>
								<tbody>

									<?php if($track_arr): ?>
									<?php for($i=0; $i < count($track_arr); $i++): ?>

									<tr>
										<td title="<?php echo e($track_arr[$i]); ?>">
											<div style="width: 150px"><?php echo e($track_arr[$i]); ?></div>
										</td>
										<td class="td-button">
											<?php echo Form::open(['url'=>route('deleteTrackingFromPallet'),'onsubmit' => 'return ConfirmDelete()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('action',$track_arr[$i]); ?>

											<?php echo Form::hidden('pallet',$warehouse->pallet); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<a class="btn btn-success" onclick="runTrackingModal(event)" href="<?php echo e(url('/admin/warehouse-tracking-move/'.$track_arr[$i])); ?>">Move</a>
										</td>
										<?php
										$notifications = '';
										if($warehouse->notifications){
											$temp = json_decode($warehouse->notifications);
											if ($temp->tracking){
												$temp_mess = json_decode($temp->tracking);
												$temp_mess = $temp_mess->message;
											}
											else{
												$temp_mess = '';
											}
											if ($temp->pallet){
												$temp_pallet = json_decode($temp->pallet);
												if (is_object($temp_pallet)) {
													$temp_pallet = $temp_pallet->other_arr.' '.$temp_pallet->empty_arr;
												}
												else{
													$temp_pallet = $temp->pallet;
												}												
											}
											else{
												$temp_pallet = '';
											}
											$notifications = $temp_pallet.' '.$temp_mess;
										}										
										?>										
										<td title="<?php echo e($notifications); ?>">
											<div style="width: 700px"><?php echo e($notifications); ?></div>
										</td>
                 
									</tr>

									<?php endfor; ?>
									<?php endif; ?>
								</tbody>
							</table>
						
						<a class="btn btn-primary" onclick="addTrackingModal(event)" href="<?php echo e(url('/admin/warehouse-add-tracking/'.$id)); ?>">Add tracking</a>
						
						</div>
					</div>
				</div>
			</div><!-- .col-md-12 -->
		</div><!-- .row -->		
		
	</div><!-- .animated -->
</div><!-- .content -->

<!-- Modal -->
<div class="modal fade" id="warehouseRunModal" tabindex="-1" role="dialog" aria-labelledby="warehouseRunModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="warehouseRunModalLabel">Editing of <span class="pallet-title"></span></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="modal-body">
					<label>New pallet No.:
						<select name="pallet"></select>
					</label>												
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Save</button>
				</div>				
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="warehouseAddTracking" tabindex="-1" role="dialog" aria-labelledby="warehouseAddTrackingLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="warehouseAddTrackingLabel">Add tracking</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="modal-body">
					<label>New tracking:
						<input type="text" name="tracking">
					</label>												
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Save</button>
				</div>				
			</form>
		</div>
	</div>
</div>

<script>

	function ConfirmDelete()
	{
		var x = confirm("Are you sure you want to delete?");
		if (x)
			return true;
		else
			return false;
	}


	var thisUrl = "<?php echo e(url('/')); ?>";


	function runTrackingModal(event)
	{
		event.preventDefault();
		const href = event.target.href;
		
		$.ajax({
			url: href,
			type: "GET",
			headers: {
				'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
			},
			success: function (data) {
				document.querySelector('#run-modal').click();
				if (data.title) $('#warehouseRunModal .pallet-title').text(data.title);
				if (data.tracking) $('#warehouseRunModal form').attr('action',thisUrl+'/admin/warehouse-tracking-move/'+data.tracking);
				if (data.palletArr) {
					const palletArr = JSON.parse(data.palletArr);
					let html = '<option value=""></option>';
					for (let i = palletArr.length - 1; i >= 0; i--) {
						html += '<option value="'+palletArr[i]+'">'+palletArr[i]+'</option>';
					}
					$('#warehouseRunModal form select').html(html);
				}				
			},
			error: function (msg) {
				alert('Ошибка admin');
			}
		});		
	}


	function addTrackingModal(event)
	{
		event.preventDefault();
		const href = event.target.href;
		
		$.ajax({
			url: href,
			type: "GET",
			headers: {
				'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
			},
			success: function (data) {
				document.querySelector('#add-tracking').click();
				if (data.id) $('#warehouseAddTracking form').attr('action',thisUrl+'/admin/warehouse-add-tracking/'+data.id);
			},
			error: function (msg) {
				alert('Ошибка admin');
			}
		});		
	}

</script>
<?php else: ?>
<h1>You cannot view this page!</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>