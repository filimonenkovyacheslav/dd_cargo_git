<style type="text/css">
	td {
		min-width: 100px;
	}
</style>
<?php
if($type === 'draft_id' || $type === 'worksheet_id') $ru = true;
else $ru = false;
?>
<center>
	<table>		
		<?php if($ru): ?>
		<tr>
			<td colspan="5">
				<img src="<?php echo e(asset('/images/cancel_img_1.png')); ?>">
				<h4 style="margin: 50px auto; width: 300px">					
					<?php echo e($old_document->uniq_id); ?>

				</h4>
			</td>
		</tr>
		<?php if($worksheet->tracking_main): ?>
		<tr>
			<td colspan="5">
				<img src="<?php echo e(asset('/images/cancel_img_2.png')); ?>">
				<h4 style="margin: 50px auto; width: 300px">
					<?php echo e($worksheet->tracking_main); ?>					
				</h4>
			</td>
		</tr>
		<?php endif; ?>
		<?php elseif(!$ru): ?>
		<tr>
			<td colspan="5">
				<h4 style="margin: 50px auto; width: 300px"><?php echo e($message); ?></h4>				
			</td>
		</tr>
		<?php endif; ?>		
		<tr>			
			<td><h3>Date</h3></td>
			<td><?php echo e($document->date); ?></td>
			<td></td>
			<td><h3>Signature</h3></td>
			<td><img src="<?php echo e(asset('/upload/signatures/'.$document->signature_for_cancel)); ?>" style="width:120px;height:100px"></td>
		</tr>
	</table>
</center>






