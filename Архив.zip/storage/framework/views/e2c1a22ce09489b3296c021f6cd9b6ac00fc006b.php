<?php $__env->startSection('content'); ?>

<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Control Panel</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminPhilIndIndex')); ?>">Control Panel</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->

<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-12">
				<a href="<?php echo e(route('exportExcelPhilInd')); ?>" style="margin-bottom: 20px;" class="btn btn-success btn-move">Export to Excel</a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>

					<?php if(session('status-error')): ?>
					<div class="alert alert-danger">
						<?php echo e(session('status-error')); ?>

					</div>
					<?php elseif(session('status')): ?>
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
					<?php endif; ?>

					<?php
						session(['this_previous_url' => url()->full()]);
					?>
					
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
					<a class="btn btn-success btn-move" href="<?php echo e(route('philIndWorksheetAddColumn')); ?>">Add column</a>
					<?php endif; ?>

					<div class="btn-move-wrapper" style="display:flex">
						<form action="<?php echo e(route('philIndWorksheetFilter')); ?>" method="GET" id="form-worksheet-table-filter" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<label class="table_columns" style="margin: 0 15px">Choose column:
								<select class="form-control" id="table_columns" name="table_columns">
									<option value="" selected="selected"></option>
									<option value="id">Id</option>
									<option value="date">Date</option>
									<option value="direction">Direction</option>
									<option value="status">Status</option>
									<option value="status_date">Status Date</option>
									<option value="order_date">Order Date</option>
									<option value="tracking_main">Main Tracking number</option>
									<option value="tracking_local">Local tracking number</option>
									<option value="pallet_number">Pallet number</option>
									<option value="comments_1">Comments 1</option>
									<option value="comments_2">Comments 2</option>
									<option value="shipper_name">Shipper\'s name</option>
									<option value="shipper_country">Shipper\'s country</option>
									<option value="shipper_region">Shipper region</option>
									<option value="shipper_city">Shipper\'s city/village</option>
									<option value="passport_number">GSTN/Passport number</option>
									<option value="return_date">Estimated return to India date</option>
									<option value="shipper_address">Shipper\'s address</option>
									<option value="standard_phone">Shipper\'s phone (standard)</option>
									<option value="shipper_phone">Shipper\'s phone (additionally)</option>
									<option value="shipper_id">Shipper\'s ID number</option>
									<option value="consignee_name">Consignee\'s name</option>
									<option value="consignee_country">Consignee\'s country</option>
									<option value="house_name">House name</option>
									<option value="post_office">Local post office</option>
									<option value="district">District/City</option>
									<option value="state_pincode">State pincode</option>
									<option value="consignee_address">Consignee\'s address</option>
									<option value="consignee_phone">Consignee\'s phone number</option>
									<option value="consignee_id">Consignee\'s ID number</option>
									<option value="shipped_items">Shipped items</option>
									<option value="shipment_val">Shipment\'s declared value</option>
									<option value="operator">Operator</option>
									<option value="courier">Courier</option>
									<option value="delivery_date_comments">Pick-up/delivery date and comments</option>
									<option value="weight">Weight</option>
									<option value="width">Width</option>
									<option value="height">Height</option>
									<option value="length">Length</option>
									<option value="volume_weight">Volume weight</option>
									<option value="lot">Lot</option>
									<option value="payment_date_comments">Payment date and comments</option>
									<option value="amount_payment">Amount of payment</option>
									<option value="status_ru">Status Ru</option>
									<option value="status_he">Status He</option>                 
								</select>
							</label>
							<label>Filter:
								<input type="search" name="table_filter_value" class="form-control form-control-sm">
							</label>
							<button type="button" id="table_filter_button" style="margin-left:30px" class="btn btn-default">Search</button>
						</form>
					</div>
					
					<div class="card-body new-worksheet">
						<div class="table-container">
							<!-- <table id="bootstrap-data-table" class="table table-striped table-bordered"> -->
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>V</th>
										<th>Id</th>
										<th>Packing List No.</th>
										<th>Date<hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
											<a class="btn btn-primary" target="_blank" href="<?php echo e(route('showPhilIndStatusDate')); ?>">Change</a>
											<?php endif; ?>
										</th>
										<th>Direction</th>
										<th>Status</th>
										<th>Status Date</th>
										<th>Order Date</th>
										<th>Main Tracking number<hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
											<a class="btn btn-primary" target="_blank" href="<?php echo e(route('showPhilIndData')); ?>">Change</a>
											<?php endif; ?>
										</th> 
										<th>Order number</th>
										<th>Parcels qty</th>
										<th>Local tracking number</th>
										<th>Pallet number</th>
										<th>Comments 1</th>
										<th>Comments 2</th>
										<th>Shipper's name</th>
										<th>Shipper's country</th>
										<th>Shipper region</th>
										<th>Shipper\'s city/village</th>
										<th>GSTN/Passport number</th>
										<th>Estimated return to India date</th>
										<th>Shipper's address</th>
										<th>Shipper's phone number (standard)</th>
										<th>Shipper's phone number (additionally)</th>
										<th>Shipper's ID number</th>
										<th>Consignee's name</th>
										<th>Consignee's country</th>
										<th>House name</th>
										<th>Local post office</th>
										<th>District/City</th>
										<th>State pincode</th>
										<th>Consignee's address</th>
										<th>Consignee's phone number</th>
										<th>Consignee's ID number</th>
										<th>Shipped items</th>
										<th>Shipment's declared value</th>
										<th>Operator</th>
										<th>Courier</th>
										<th>Pick-up/delivery date and comments</th>
										<th>Weight</th>
										<th>Width</th>
										<th>Height</th>
										<th>Length</th>
										<th>Volume weight</th>										
										<th>Lot<hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
											<a class="btn btn-primary" target="_blank" href="<?php echo e(route('changePhilIndStatus')); ?>">Change</a>
											<?php endif; ?>
										</th>
										<th>Payment date and comments</th>
										<th>Amount of payment</th>
										<th>Status Ru</th>
										<th>Status He</th>										
																			
										<?php if($new_column_1): ?>
										<th><?php echo e($new_column_1); ?><hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

											<?php echo Form::open(['url'=>route('philIndWorksheetDeleteColumn'),'onsubmit' => 'return ConfirmDeleteColumn()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('name_column','new_column_1'); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<?php endif; ?>
										</th>
										<?php endif; ?>
										<?php if($new_column_2): ?>
										<th><?php echo e($new_column_2); ?><hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

											<?php echo Form::open(['url'=>route('philIndWorksheetDeleteColumn'),'onsubmit' => 'return ConfirmDeleteColumn()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('name_column','new_column_2'); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<?php endif; ?>
										</th>
										<?php endif; ?>
										<?php if($new_column_3): ?>
										<th><?php echo e($new_column_3); ?><hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

											<?php echo Form::open(['url'=>route('philIndWorksheetDeleteColumn'),'onsubmit' => 'return ConfirmDeleteColumn()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('name_column','new_column_3'); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<?php endif; ?>
										</th>
										<?php endif; ?>
										<?php if($new_column_4): ?>
										<th><?php echo e($new_column_4); ?><hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

											<?php echo Form::open(['url'=>route('philIndWorksheetDeleteColumn'),'onsubmit' => 'return ConfirmDeleteColumn()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('name_column','new_column_4'); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<?php endif; ?>
										</th>
										<?php endif; ?>
										<?php if($new_column_5): ?>
										<th><?php echo e($new_column_5); ?><hr>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

											<?php echo Form::open(['url'=>route('philIndWorksheetDeleteColumn'),'onsubmit' => 'return ConfirmDeleteColumn()', 'class'=>'form-horizontal','method' => 'POST']); ?>

											<?php echo Form::hidden('name_column','new_column_5'); ?>

											<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

											<?php echo Form::close(); ?>


											<?php endif; ?>
										</th>
										<?php endif; ?>																			

										<th>Consignee's name (for customs)</th>
										<th>Consignee's address (for customs)</th>
										<th>Consignee's phone number (for customs)</th>
										<th>Consignee's ID number (for customs)</th>

									</tr>

								</thead>
								<tbody>

									<?php if(isset($phil_ind_worksheet_obj)): ?>
									<?php $__currentLoopData = $phil_ind_worksheet_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<tr class="<?php echo e($row->background); ?>">
										<td class="td-checkbox">
											<input type="hidden" name="old_color[]" value="<?php echo e($row->background); ?>">
											<input type="checkbox" name="row_id[]" value="<?php echo e($row->id); ?>">
										</td>
										<td title="<?php echo e($row->id); ?>">
											<div class="div-22"><?php echo e($row->id); ?></div>
										</td>
										<td title="<?php echo e($row->getLastDocUniq()); ?>">
											<div class="div-3"><?php echo e($row->getLastDocUniq()); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->date); ?>">
											<div class="div-3"><?php echo e($row->date); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->direction); ?>">
											<div class="div-3"><?php echo e($row->direction); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->status); ?>">
											<div data-name="status" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->status); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->status_date); ?>">
											<div class="div-3"><?php echo e($row->status_date); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->order_date); ?>">
											<div data-name="order_date" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->order_date); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->tracking_main); ?>">
											<div data-name="tracking_main" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->tracking_main); ?></div>
										</td>
										<td class="td-button" title="<?php echo e($row->order_number); ?>">
											<div class="div-22"><?php echo e($row->order_number); ?></div>
										</td>
										<td title="<?php echo e($row->parcels_qty); ?>">
											<div class="div-22"><?php echo e($row->parcels_qty); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->tracking_local); ?>">
											<div data-name="tracking_local" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->tracking_local); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->pallet_number); ?>">
											<div data-name="pallet_number" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->pallet_number); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editComments-eng')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->comments_1); ?>">
											<div data-name="comments_1" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->comments_1); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->comments_2); ?>">
											<div data-name="comments_2" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->comments_2); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_name); ?>">
											<div data-name="shipper_name" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipper_name); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_country); ?>">
											<div data-name="shipper_country" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipper_country); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_region); ?>">
											<div data-name="shipper_region" data-id="<?php echo e($row->id); ?>" class="div-2"><?php echo e($row->shipper_region); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_city); ?>">
											<div data-name="shipper_city" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipper_city); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->passport_number); ?>">
											<div data-name="passport_number" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->passport_number); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->return_date); ?>">
											<div data-name="return_date" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->return_date); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_address); ?>">
											<div data-name="shipper_address" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipper_address); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->standard_phone); ?>">
											<div data-name="standard_phone" data-id="<?php echo e($row->id); ?>" class="div-4"><?php echo e($row->standard_phone); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_phone); ?>">
											<div data-name="shipper_phone" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipper_phone); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipper_id); ?>">
											<div data-name="shipper_id" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipper_id); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->consignee_name); ?>">
											<div data-name="consignee_name" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_name); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->consignee_country); ?>">
											<div data-name="consignee_country" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_country); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->house_name); ?>">
											<div data-name="house_name" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->house_name); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->post_office); ?>">
											<div data-name="post_office" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->post_office); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->district); ?>">
											<div data-name="district" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->district); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->state_pincode); ?>">
											<div data-name="state_pincode" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->state_pincode); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->consignee_address); ?>">
											<div data-name="consignee_address" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_address); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->consignee_phone); ?>">
											<div data-name="consignee_phone" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_phone); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->consignee_id); ?>">
											<div data-name="consignee_id" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_id); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipped_items); ?>">
											<div data-name="shipped_items" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipped_items); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?> <?php if($row->getLastDocUniq()): ?>pdf-file <?php endif; ?>" title="<?php echo e($row->shipment_val); ?>">
											<div data-name="shipment_val" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->shipment_val); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->operator); ?>">
											<div data-name="operator" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->operator); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->courier); ?>">
											<div data-name="courier" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->courier); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->delivery_date_comments); ?>">
											<div data-name="delivery_date_comments" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->delivery_date_comments); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->weight); ?>">
											<div data-name="weight" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->weight); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->width); ?>">
											<div data-name="width" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->width); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->height); ?>">
											<div data-name="height" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->height); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->length); ?>">
											<div data-name="length" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->length); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editColumns-eng-2')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->volume_weight); ?>">
											<div data-name="volume_weight" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->volume_weight); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->lot); ?>">
											<div data-name="lot" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->lot); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->payment_date_comments); ?>">
											<div data-name="payment_date_comments" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->payment_date_comments); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->amount_payment); ?>">
											<div data-name="amount_payment" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->amount_payment); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->status_ru); ?>">
											<div class="div-3"><?php echo e($row->status_ru); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->status_he); ?>">
											<div class="div-3"><?php echo e($row->status_he); ?></div>
										</td>
										
										<?php if($new_column_1): ?>
										<td title="<?php echo e($row->new_column_1); ?>">
											<div class="div1"><?php echo e($row->new_column_1); ?></div>
										</td>
										<?php endif; ?>
										<?php if($new_column_2): ?>
										<td title="<?php echo e($row->new_column_2); ?>">
											<div class="div1"><?php echo e($row->new_column_2); ?></div>
										</td>
										<?php endif; ?>
										<?php if($new_column_3): ?>
										<td title="<?php echo e($row->new_column_3); ?>">
											<div class="div1"><?php echo e($row->new_column_3); ?></div>
										</td>
										<?php endif; ?>
										<?php if($new_column_4): ?>
										<td title="<?php echo e($row->new_column_4); ?>">
											<div class="div1"><?php echo e($row->new_column_4); ?></div>
										</td>
										<?php endif; ?>
										<?php if($new_column_5): ?>
										<td title="<?php echo e($row->new_column_5); ?>">
											<div class="div1"><?php echo e($row->new_column_5); ?></div>
										</td>
										<?php endif; ?>										 

										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->consignee_name_customs); ?>">
											<div data-name="consignee_name_customs" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_name_customs); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->consignee_address_customs); ?>">
											<div data-name="consignee_address_customs" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_address_customs); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->consignee_phone_customs); ?>">
											<div data-name="consignee_phone_customs" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_phone_customs); ?></div>
										</td>
										<td class="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>allowed-update <?php endif; ?>" title="<?php echo e($row->consignee_id_customs); ?>">
											<div data-name="consignee_id_customs" data-id="<?php echo e($row->id); ?>" class="div-3"><?php echo e($row->consignee_id_customs); ?></div>
										</td>
                                                               
									</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>

							<?php if(isset($data)): ?>
							<?php echo e($phil_ind_worksheet_obj->appends($data)->links()); ?>

							<?php else: ?>
							<?php echo e($phil_ind_worksheet_obj->links()); ?>

							<?php endif; ?>

							<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>

							<div class="checkbox-operations">
								
								<?php echo Form::open(['url'=>route('addPhilIndDataById'), 'onsubmit' => 'return CheckColor(event)', 'class'=>'worksheet-add-form','method' => 'POST']); ?>


								<input type="hidden" name="which_admin" value="en">

								<label>Select action with selected rows:
									<select class="form-control" name="checkbox_operations_select">
										<option value=""></option>
										<?php endif; ?>

										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('changeColor')): ?>
										<option value="color">Change color</option>
										<?php endif; ?>

										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>										
										<option value="delete">Delete</option>
										<option value="change">Change</option>	
										<?php endif; ?>
										
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
										<option value="cancel-pdf">Cancel PDF</option>
										<option value="download-pdf">Download PDF</option>
										<?php endif; ?>
										
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
									</select>
								</label>

								<label class="checkbox-operations-change">Choose column:
									<select class="form-control" id="phil-ind-tracking-columns" name="phil-ind-tracking-columns">
										<option value="" selected="selected"></option>
										<option value="status">Status</option>
										<option value="tracking_local">Local tracking number</option>
										<option value="pallet_number">Pallet number</option>
										<option value="comments_1">Comments 1</option>
										<option value="comments_2">Comments 2</option>
										<option value="operator">Operator</option>
										<option value="courier">Courier</option>
										<option value="delivery_date_comments">Pick-up/delivery date and comments</option>
										<option value="weight">Weight</option>
										<option value="width">Width</option>
										<option value="height">Height</option>
										<option value="length">Length</option>
										<option value="volume_weight">Volume weight</option>
										<option value="lot">Lot</option>
										<option value="payment_date_comments">Payment date and comments</option>
										<option value="amount_payment">Amount of payment</option>   
									</select>
								</label>

								<label class="checkbox-operations-color">Choose color:
									<select class="form-control" name="tr_color">
										<option value="" selected="selected"></option>
										<option value="transparent">No color</option>
										<option value="tr-orange">Orange</option>
										<option value="tr-yellow">Yellow</option>
										<option value="tr-green">Green</option>
										<option value="tr-blue">Blue</option>
									</select>
								</label>

								<label class="phil-ind-value-by-tracking checkbox-operations-change">Input value:
									<textarea class="form-control" name="value-by-tracking"></textarea>
									<input type="hidden" name="status_ru">
									<input type="hidden" name="status_he">
									<input type="hidden" name="shipper_country_val">
									<input type="hidden" name="consignee_country_val">
								</label>

								<?php echo Form::button('Save',['class'=>'btn btn-primary checkbox-operations-change','type'=>'submit']); ?>

								<?php echo Form::close(); ?>


								<?php echo Form::open(['url'=>route('deletePhilIndWorksheetById'),'method' => 'POST']); ?>

								<?php echo Form::button('Delete',['class'=>'btn btn-danger  checkbox-operations-delete','type'=>'submit','onclick' => 'ConfirmDelete(event)']); ?>

								<?php echo Form::close(); ?>



								<form class="checkbox-operations-change-one" action="<?php echo e(url('/admin/phil-ind-worksheet/')); ?>" method="GET">
									<?php echo csrf_field(); ?>	
								</form>

								<form class="checkbox-operations-cancel-pdf" action="<?php echo e(route('cancelPdf')); ?>" method="POST">
									<?php echo csrf_field(); ?>	
									<input type="hidden" name="eng_worksheet_id" class="cancel-pdf">
								</form>

								<form class="checkbox-operations-download-pdf" action="<?php echo e(route('downloadAllPdf')); ?>" method="POST">
									<?php echo csrf_field(); ?>	
									<input type="hidden" name="id" class="download-pdf">
									<input type="hidden" name="type" value="eng_worksheet_id">
								</form>

							</div>
							
							<?php endif; ?>
						
						</div>
					</div>
				</div>
			</div><!-- .col-md-12 -->
		</div><!-- .row -->		
		
	</div><!-- .animated -->
</div><!-- .content -->


<!-- Modal -->
<a id="update-cell" data-toggle="modal" data-target="#updateCellModal"></a>

<div class="modal fade" id="updateCellModal" tabindex="-1" role="dialog" aria-labelledby="updateCellModalLabel" aria-hidden="true" style="background: rgba(0, 0, 0, 0.4);">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="updateCellModalLabel">Update cell</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?php echo e(route('addPhilIndDataById')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="modal-body">
					<div class="form-group phil-ind-value-by-tracking">
						<textarea class="form-control" name="value-by-tracking"></textarea>
						<input type="hidden" name="status_ru">
						<input type="hidden" name="status_he">
						<input type="hidden" name="shipper_country_val">
						<input type="hidden" name="consignee_country_val">
					</div>					
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary" style="font-size:.8rem">SAVE</button>
				</div>
			</form>
		</div>
	</div>
</div>


<script>

	function ConfirmDeleteColumn()
	{
		var x = confirm("Are you sure you want to delete?");
		if (x)
			return true;
		else
			return false;
	}


	function ConfirmDelete(event)
	{
		event.preventDefault();
		const form = event.target.parentElement;
		const data = new URLSearchParams(new FormData(form)).toString();
		location.href = '/admin/to-trash?'+data+'&table=phil_ind_worksheet';
	}

	
	function CheckColor(event){
		
		$('.alert.alert-danger').remove();
		const form = event.target;
		const color = document.querySelector('[name="tr_color"]').value;

		if (color) {
			event.preventDefault();
			$.ajax({
				url: '/admin/check-row-color/',
				type: "POST",
				data: $(form).serialize(),
				headers: {
					'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
				},
				success: function (data) {
					console.log(data);
					if (data.error) {
						$('.card-header').after(`
							<div class="alert alert-danger">
							`+data.error+`										
							</div>`)
						return 0;
					}
					else{
						form.submit();
					}
				},
				error: function (msg) {
					alert('Admin error');
				}
			});
		}		
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.phil_ind_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>