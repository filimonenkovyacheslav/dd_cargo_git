<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-user')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<div class="card-body">	

					<?php if(isset($user)): ?>				

						<?php echo Form::open(['url'=>route('userUpdate', ['id'=>$user->id]), 'class'=>'form-horizontal','method' => 'POST']); ?>


						<div class="form-group">
							<?php echo Form::label('name','Имя',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('name',$user->name,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('email','E-mail',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::email('email',$user->email,['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('password','Пароль',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('password','',['class' => 'form-control']); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('role','Роль',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('role', $roles_arr, $user->role,['class' => 'form-control']); ?>

							</div>
						</div>
						

						<?php echo Form::button('Сохранить',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::close(); ?>

						<?php endif; ?>

					</div>
				</div>
			</div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<?php else: ?>
<h1>Вы не можете просматривать эту страницу!</h1>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>