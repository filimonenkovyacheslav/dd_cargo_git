<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('downloadDirectory')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="path" value="<?php echo e($item['path']); ?>">
	<button type="submit"><?php echo e($item['name']); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>