<style type="text/css">
	td,th {
		min-width: 100px;
		border: 1px solid black;
		padding: 3px;
	}
	.without-border td,.without-border th {
		border: none;
	}
	table{
		font-size: 10px;
		border-collapse: collapse;
		border: 2px solid black;
		text-align: center;
		vertical-align: middle;
	}
	table img{
		width:200px;
		height:100px;
	}
</style>
<center style="font-family: 'DejaVu Sans'">

	<?php if($cancel): ?>
	<h1 style="color:red">CANCELED</h1>
	<?php endif; ?>
	
	<table>	
		<tr>
			<th colspan="4" style="font-size:14px">
				ПАКИНГ-ЛИСТ <?php echo e($document->uniq_id); ?>

			</th>
		</tr>	
		<tr class="without-border">			
			<th>Номер посылки</th>
			<td><?php echo e($tracking); ?></td>
			<th>Вес посылки</th>
			<td><?php echo e($worksheet->weight); ?></td>
		</tr>
		<tr class="without-border">			
			<th>Дата</th>
			<td><?php echo e($document->date); ?></td>
			<th>Габариты посылки</th>
			<td><?php echo e($worksheet->width); ?>x<?php echo e($worksheet->height); ?>x<?php echo e($worksheet->length); ?></td>
		</tr>
		<tr>
			<th colspan="2">
				ИНФОРМАЦИЯ ОБ ОТПРАВИТЕЛЕ
			</th>
			<th colspan="2">
				ИНФОРМАЦИЯ О ПОЛУЧАТЕЛЕ
			</th>
		</tr>
		<tr>
			<th>Имя</th>
			<td><?php echo e($worksheet->sender_name); ?></td>
			<th>Имя</th>
			<td><?php echo e($worksheet->recipient_name); ?></td>
		</tr>	
		<tr>
			<th>Страна</th>
			<td><?php echo e($worksheet->sender_country); ?></td>
			<th>Страна</th>
			<td><?php echo e($worksheet->recipient_country); ?></td>
		</tr>
		<tr>
			<th>Адрес</th>
			<td><?php echo e($worksheet->sender_address); ?></td>
			<th>Адрес</th>
			<td><?php echo e($worksheet->recipient_postcode.', '); ?><?php echo e(($worksheet->region) ? $worksheet->region.', ':''); ?><?php echo e(($worksheet->district) ? $worksheet->district.', ':''); ?><?php echo e($worksheet->recipient_city.', '); ?><?php echo e($worksheet->recipient_street.', '); ?><?php echo e($worksheet->recipient_house.', '); ?><?php echo e(($worksheet->body) ? $worksheet->body.', ':''); ?><?php echo e($worksheet->recipient_room); ?></td>
		</tr>
		<tr>
			<th>Номер телефона</th>
			<td><?php echo e($worksheet->standard_phone); ?></td>
			<th>Номер телефона</th>
			<td><?php echo e($worksheet->recipient_phone); ?></td>
		</tr>	
		<tr>
			<th colspan="4">
				ОПИСАНИЕ СОДЕРЖИМОГО ПОСЫЛКИ
			</th>
		</tr>
		<tr>
			<th>№</th>
			<th colspan="2">ОПИСАНИЕ</td>
			<th>Количество</th>
		</tr>
		<?php
		$number = 1;
		$items = explode(";", $worksheet->package_content);            
		?>

		<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<?php if(strripos($item, ':') !== false): ?>
			<tr>
				<td><?php echo e($number); ?></td>
				<td colspan="2"><?php echo e(explode(":", $item)[0]); ?></td>
				<td><?php echo e(explode(":", $item)[1]); ?></td>
			</tr>
			<?php elseif(strripos($item, '-') !== false): ?>
			<tr>
				<td><?php echo e($number); ?></td>
				<td colspan="2"><?php echo e(explode("-", $item)[0]); ?></td>
				<td><?php echo e(explode("-", $item)[1]); ?></td>				
			</tr>			
			<?php endif; ?>	
			<?php
			$number++;
			?>		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th colspan="3">Декларируемая стоимость посылки</td>
			<td><?php echo e($worksheet->package_cost); ?></td>
		</tr>
		<tr style="text-align:left;">
			<td colspan="4">
				<h3>ГАРАНТИЙНЫЕ ОБЯЗАТЕЛЬСТВА ОТПРАВИТЕЛЯ:</h3>
				<p>Я, <?php echo e($worksheet->sender_name); ?>, нижеподписавшийся/нижеподписавшаяся, подтверждаю, что являюсь отправителем всех вышеуказанных предметов, перечисленных в этом упаковочном листе, включая прилагаемый дополнительный подписанный упаковочный лист (если таковой имеется), и что я лично их упаковал. Подписывая форму, я гарантирую следующее:</p>
				<ol>
					<li>в этом подробном упаковочном листе указано точное и правильное количество предметов, содержащихся в коробке;</li>
					<li>НЕТ необъявленных, запрещенных, незаконных или запрещенных предметов, включая:
						<ul>
							<li>лекарства</li>
							<li>скоропортящиеся продукты</li>
							<li>оружие</li>
							<li>наркотики</li>
							<li>органические материалы</li>
							<li>боеприпасы</li>
							<li>горючие предметы</li>
							<li>наличные деньги</li>
							<li>ювелирные изделия</li>
							<li>порнографические материалы</li>
						</ul>
					</li>
					<li>все предметы, содержащиеся в коробке, предназначены исключительно для личного некоммерческого использования.</li>
					<li>в случае нарушения данных гарантий я согласен оплатить расходы, понесенные по моей вине, вызванные задержками в таможенном оформлении и / или возврате посылки со склада в Израиле или из страны назначения мне.</li>
				</ol>
				<p>Подписывая эту форму, я подтверждаю, что я прочитал и понял все письменные и прилагаемые положения и условия</p>
			</td>
		</tr>
		<tr class="without-border">			
			<th>Имя отправителя</th>
			<td><?php echo e($worksheet->sender_name); ?></td>
			<th>Подпись отправителя</th>
			<td><img src="<?php echo e(asset('/upload/signatures/'.$document->signature)); ?>"></td>
		</tr>
	</table>
</center>








