<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChinaWorksheet extends Model
{
    protected $table = 'china_worksheet';
}
