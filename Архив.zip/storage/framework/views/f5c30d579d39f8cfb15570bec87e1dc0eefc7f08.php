<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPost')): ?>
<!-- <div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1>Панель управления</h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo e(route('adminIndex')); ?>">Панель управления</a></li>
					<li class="active"><?php echo e($title); ?></li>
				</ol>                        
			</div>
		</div>
	</div>
</div> -->
<div class="content mt-3">
	<div class="animated fadeIn">
		<div class="row">
			
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title"><?php echo e($title); ?></strong>
					</div>
					<div class="card-body">					

						<?php echo Form::open(['url'=>route('changeNewStatus'), 'class'=>'form-horizontal worksheet-add-form','method' => 'POST']); ?>


						<div class="form-group">
							<?php echo Form::label('batch_number','Выберите номер партии',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('batch_number', $number_arr, '',['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('status','Статус',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::select('status', array('' => '', 'Доставляется на склад в стране отправителя' => 'Доставляется на склад в стране отправителя', 'На складе в стране отправителя' => 'На складе в стране отправителя', 'На таможне в стране отправителя' => 'На таможне в стране отправителя', 'Доставляется в страну получателя' => 'Доставляется в страну получателя', 'На таможне в стране получателя' => 'На таможне в стране получателя', 'Доставляется получателю' => 'Доставляется получателю', 'Доставлено' => 'Доставлено', 'Возврат' => 'Возврат', 'Коробка' => 'Коробка', 'Забрать' => 'Забрать', 'Уточнить' => 'Уточнить', 'Думают' => 'Думают', 'Отмена' => 'Отмена'), '',['class' => 'form-control']); ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('status_en_disabled','Статус (ENG)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_en_disabled',old('status_en'),['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_en',old('status_en'),[]); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('status_he_disabled','Статус (HE)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_he_disabled',old('status_he'),['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_he',old('status_he'),[]); ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('status_ua_disabled','Статус (UA)',['class' => 'col-md-2 control-label']); ?>

							<div class="col-md-8">
								<?php echo Form::text('status_ua_disabled',old('status_ua'),['class' => 'form-control', 'disabled' => 'disabled']); ?>

								<?php echo Form::hidden('status_ua',old('status_ua'),[]); ?>

							</div>
						</div>

						<?php echo Form::button('Сохранить',['class'=>'btn btn-primary','type'=>'submit']); ?>

						<?php echo Form::close(); ?>


					</div>
				</div>
			</div>


		</div>
	</div><!-- .animated -->
</div><!-- .content -->

<?php else: ?>
<h1>Вы не можете просматривать эту страницу!</h1>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>